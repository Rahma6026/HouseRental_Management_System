

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

public class PaymentTest {
    private Payment payment;

    @Before
    public void setUp() {
        payment = new Payment("TEN001", "HOUSE001", 1500.00);
    }

    @Test
    public void InitialStatusPending() {
        assertEquals("Pending", payment.getStatus());
    }

    @Test
    public void ProcessPayment() {
        payment.processPayment();
        assertEquals("Completed", payment.getStatus());
        assertFalse(payment.getPaymentHistory().isEmpty());
    }

    @Test
    public void RefundPaymentWhenCompleted() {
        payment.processPayment();
        payment.refundPayment();
        assertEquals("Refunded", payment.getStatus());
    }

    @Test
    public void RefundPaymentWhenNotCompleted() {
        payment.refundPayment(); 
        assertEquals("Pending", payment.getStatus());
    }

    @Test
    public void UpdatePaymentStatus() {
        payment.updatePaymentStatus("Overdue");
        assertEquals("Overdue", payment.getStatus());
    }

    @Test
    public void SendPaymentReminder() {
        payment.sendPaymentReminder();
        assertEquals("Pending", payment.getStatus()); 
    }

    @Test
    public void ConfirmPaymentReceipt_Completed() {
        payment.processPayment();
        payment.confirmPaymentReceipt();  
        assertEquals("Completed", payment.getStatus());
    }

    @Test
    public void ConfirmPaymentReceipt_NotCompleted() {
        payment.confirmPaymentReceipt(); 
        assertEquals("Pending", payment.getStatus());
    }

    @Test
    public void TrackPaymentStatus() {
        payment.trackPaymentStatus(); 
        assertEquals("Pending", payment.getStatus());
    }

    @Test
    public void ViewPendingPayments_WhenPending() {
        payment.viewPendingPayments(); 
        assertEquals("Pending", payment.getStatus());
    }

    @Test
    public void ViewPendingPayments_WhenNotPending() {
        payment.processPayment();
        payment.viewPendingPayments(); 
        assertEquals("Completed", payment.getStatus());
    }

    @Test
    public void CalculateLateFees_PositiveDays() {
        payment.calculateLateFees(4); 
        assertEquals("Pending", payment.getStatus()); 
    }

    @Test
    public void CalculateLateFees_NoLateDays() {
        payment.calculateLateFees(0);  
        assertEquals("Pending", payment.getStatus()); 
    }

    @Test
    public void ExportPaymentsToCSV() {
        payment.processPayment();
        payment.exportPaymentsToCSV();  
        assertFalse(payment.getPaymentHistory().isEmpty());
    }

    @Test
    public void IntegrateWithBank() {
        payment.integrateWithBank("Bank Asia");
        assertEquals("Pending", payment.getStatus()); 
    }

    @Test
    public void AddAndSetupAutoPaymentMethod() {
        payment.addPaymentMethod("M001", "Visa Card");
        payment.setupAutoPayment("M001"); 
        assertTrue(payment.getPaymentHistory().isEmpty()); 
    }

    @Test
    public void SetupAutoPaymentMethod_NotFound() {
        payment.setupAutoPayment("UNKNOWN");  
        assertTrue(payment.getPaymentHistory().isEmpty()); 
    }

    @Test
    public void RemovePaymentMethod() {
        payment.addPaymentMethod("M002", "MasterCard");
        payment.removePaymentMethod("M002"); 
        payment.setupAutoPayment("M002");
        assertTrue(payment.getPaymentHistory().isEmpty());
    }

    @Test
    public void RemovePaymentMethod_NotFound() {
        payment.removePaymentMethod("UNKNOWN");  
        assertEquals("Pending", payment.getStatus()); 
    }

    @Test
    public void Getters() {
        assertNotNull(payment.getPaymentId());
        assertEquals(1500.00, payment.getAmount(), 0.001);
        assertTrue(payment.getPaymentDate() instanceof Date);
        assertEquals("Pending", payment.getStatus());
    }
}
