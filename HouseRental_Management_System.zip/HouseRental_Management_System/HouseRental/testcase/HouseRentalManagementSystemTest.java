

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HouseRentalManagementSystemTest {

    private Admin admin;
    private Tenant tenant;
    private Owner owner;

    @Before
    public void setUp() {
      
        admin = new Admin("Rahma Mahbub", "rahmamahbub@gmail.com");
        tenant = new Tenant("TENANT001", "Rahma", "rahma@gmail.com", "password002255");
        owner = new Owner("OWNER001", "Tammana");

        
        admin.approveOwnerRegistration(owner.getOwnerId());
        admin.approveTenantRegistration(tenant.getTenantId());
        tenant.viewAvailableProperties();
        owner.viewProperties();
    }

    @Test
    public void testAdminOperations() {
        admin.approveOwnerRegistration("OWNER001");
        admin.approveTenantRegistration("TENANT001");

        admin.manageUsers();
        admin.viewSystemReports();
        assertEquals("Rahma Mahbub", admin.getUsername()); 
      
    }

    @Test
    public void testTenantOperations() {
        tenant.sendMaintenanceRequest("Request001", "Leaky faucet in bathroom");
        tenant.submitFeedback("Great service and well-maintained property.");

        assertEquals("Rahma", tenant.getName());
        assertEquals("rahma@gmail.com", tenant.getEmail());
    }

    @Test
    public void testRentalSimulation() {
        String tenantName = tenant.getName();
        String propertyId = "House001";
        String ownerName = owner.getName();

        String expectedRentalMessage = "Tenant " + tenantName + " is renting property " + propertyId + ".";
        String expectedApprovalMessage = "Rental request approved by owner " + ownerName + ".";

        System.out.println(expectedRentalMessage);
        System.out.println(expectedApprovalMessage);

        assertNotNull(tenantName);
        assertNotNull(ownerName);
    }
}
