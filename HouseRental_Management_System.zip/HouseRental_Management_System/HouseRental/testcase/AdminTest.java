

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;

public class AdminTest {

    private Admin admin;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @Before
    public void setUp() {
        admin = new Admin("adminUser", "adminPass");
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void testConstructorInitializesFields() {
        assertNotNull(admin.getAdminId());
        assertEquals("adminUser", admin.getUsername());
        assertTrue(admin.getAssignedTasks().isEmpty());
    }

    @Test
    public void testLoginSuccess() {
        admin.loginAdmin("adminUser", "adminPass");
        assertTrue(outContent.toString().contains("Admin login successful."));
    }

    @Test
    public void testLoginFailure() {
        admin.loginAdmin("wrongUser", "wrongPass");
        assertTrue(outContent.toString().contains("Invalid admin credentials."));
    }

    @Test
    public void testApproveOwnerRegistration() {
        admin.approveOwnerRegistration("OWNER123");
        assertTrue(outContent.toString().contains("Approved registration for owner with ID: OWNER123"));
    }

    @Test
    public void testApproveTenantRegistration() {
        admin.approveTenantRegistration("TENANT456");
        assertTrue(outContent.toString().contains("Approved registration for tenant with ID: TENANT456"));
    }

    @Test
    public void testManageUsers() {
        admin.manageUsers();
        assertTrue(outContent.toString().contains("Managing users..."));
    }

    @Test
    public void testViewSystemReports() {
        admin.viewSystemReports();
        assertTrue(outContent.toString().contains("System reports viewed."));
    }

    @Test
    public void testResetPassword() {
        admin.resetPassword("newPass");
        outContent.reset();
        admin.loginAdmin("adminUser", "newPass");
        assertTrue(outContent.toString().contains("Admin login successful."));
    }

    @Test
    public void testAuditLogsNotEmptyAfterActions() {
        admin.manageUsers();
        List<String> logs = admin.auditLogs();
        assertFalse(logs.isEmpty());
    }

    @Test
    public void testAssignTask() {
        admin.assignTask("Review Reports");
        assertTrue(admin.getAssignedTasks().contains("Review Reports"));
        assertTrue(outContent.toString().contains("Task assigned to admin: Review Reports"));
    }

    @Test
    public void testViewAssignedTasks() {
        admin.assignTask("Check Complaints");
        outContent.reset();
        admin.viewAssignedTasks();
        assertTrue(outContent.toString().contains("Check Complaints"));
    }

    @Test
    public void testGetAdminId() {
        assertNotNull(admin.getAdminId());
        assertTrue(admin.getAdminId().startsWith("A-"));
    }

    @Test
    public void testGetUsername() {
        assertEquals("adminUser", admin.getUsername());
    }

    @Test
    public void testGetAssignedTasksEmptyInitially() {
        assertTrue(admin.getAssignedTasks().isEmpty());
    }

    @Test
    public void testAuditLogsPrintsToConsole() {
        admin.manageUsers();
        outContent.reset();
        admin.auditLogs();
        assertTrue(outContent.toString().contains("Admin managing users"));
    }

    @Test
    public void testGetEmailReturnsNull() {
        assertNull(admin.getEmail());
    }
    
    @Test
    public void testLoginWithNullUsername() {
        admin.loginAdmin(null, "adminPass");
        assertTrue(outContent.toString().contains("Invalid admin credentials."));
    }

    @Test
    public void testLoginWithShortPassword() {
        admin.loginAdmin("adminUser", "1234"); 
        assertTrue(outContent.toString().contains("Invalid admin credentials."));
    }

}
