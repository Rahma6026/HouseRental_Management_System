

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ReportTest {
    private Report report;

    @Before
    public void setUp() {
        report = new Report("Monthly", "Admin");
    }

    @Test
    public void GenerateMonthlyReport() {
        report.generateMonthlyReport();
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void GenerateYearlyReport() {
        report.generateYearlyReport();
        assertEquals("Yearly", report.getReportType());
    }

    @Test
    public void GenerateHouseReport() {
        report.generateHouseReport();
        assertEquals("House", report.getReportType());
    }

    @Test
    public void GenerateOwnerReport() {
        report.generateOwnerReport();
        assertEquals("Owner", report.getReportType());
    }

    @Test
    public void GenerateTenantReport() {
        report.generateTenantReport();
        assertEquals("Tenant", report.getReportType());
    }

    @Test
    public void GenerateComplaintReport() {
        report.generateComplaintReport();
        assertEquals("Complaint", report.getReportType());
    }

    @Test
    public void GeneratePaymentReport() {
        report.generatePaymentReport();
        assertEquals("Payment", report.getReportType());
    }

    @Test
    public void ExportReport() {
        assertFalse(report.isExported());
        report.exportReport();
        assertTrue(report.isExported());
        assertEquals(true, report.isExported());
    }

    @Test
    public void AutoEmailReports() {
        assertFalse(report.isEmailed());
        report.autoEmailReports("tamu@gmail.com");
        assertTrue(report.isEmailed());
        assertEquals(true, report.isEmailed());
    }

    @Test
    public void DeleteReport() {
        report.generateMonthlyReport();
        report.deleteReport();
        report.validateReportData();
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void ValidateReportData_WhenEmpty() {
        report.deleteReport();
        report.validateReportData();
        assertEquals("Monthly", report.getReportType()); // Initial value remains
    }

    @Test
    public void ValidateReportData_WhenFilled() {
        report.generateMonthlyReport();
        report.validateReportData();
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void CustomizeReportLayout() {
        report.customizeReportLayout("Portrait");
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void SummarizeReport() {
        report.generateMonthlyReport();
        report.summarizeReport();
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void FilterReport_WithMatch() {
        report.generateMonthlyReport();
        report.filterReport("tenant");
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void FilterReport_NoMatch() {
        report.generateMonthlyReport();
        report.filterReport("nonexistent");
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void ViewReport() {
        report.generateMonthlyReport();
        report.viewReport();
        assertNotNull(report.getReportId());
        assertEquals("Monthly", report.getReportType());
    }

    @Test
    public void Getters() {
        assertNotNull(report.getReportId());
        assertEquals("Monthly", report.getReportType());
        assertFalse(report.isExported());
        assertFalse(report.isEmailed());
        assertEquals(false, report.isExported());
        assertEquals(false, report.isEmailed());
    }
}
