

import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class SystemAuditTest {

    private SystemAudit audit;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    
    @Before
    public void setUp() {
        audit = new SystemAudit();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void testLogUserAction() {
        audit.logUserAction("UA1001", "User logged in");
        assertTrue(outContent.toString().contains("User action logged: User logged in"));
    }

    @Test
    public void testViewSystemLogs_EmptyInitially() {
        audit.viewSystemLogs();
        assertTrue(outContent.toString().contains("Viewing system logs:"));
    }

    @Test
    public void testGenerateAuditReport() {
        audit.generateAuditReport("AR1001");
        assertTrue(outContent.toString().contains("Generating audit report with ID: AR1001"));
    }

    @Test
    public void testTrackSystemChanges() {
        audit.trackSystemChanges("SC1001", "Updated server settings");
        assertTrue(outContent.toString().contains("System change tracked: Updated server settings"));
    }

    @Test
    public void testCheckSecurityBreach() {
        audit.checkSecurityBreach();
        assertTrue(outContent.toString().contains("Checking for security breaches..."));
    }

    @Test
    public void testReviewUserActivity_MatchAndNoMatch() {
        audit.logUserAction("USER1001_ACTION1", "Changed password");
        audit.logUserAction("USER2002_ACTION2", "Updated email");
        audit.reviewUserActivity("USER1001");
        assertTrue(outContent.toString().contains("Reviewing activity for user ID: USER1001"));
        assertTrue(outContent.toString().contains("User Action ID: USER1001_ACTION1 - Action: Changed password"));
    }

    @Test
    public void testMonitorSystemHealth() {
        audit.monitorSystemHealth();
        assertTrue(outContent.toString().contains("Monitoring system health..."));
    }

    @Test
    public void testHandleUnauthorizedAccess() {
        audit.handleUnauthorizedAccess("LOG001", "Attempted login from blacklisted IP");
        assertTrue(outContent.toString().contains("Unauthorized access attempt detected: Attempted login from blacklisted IP"));
    }

    @Test
    public void testAnalyzeSystemPerformance() {
        audit.analyzeSystemPerformance();
        assertTrue(outContent.toString().contains("Analyzing system performance..."));
    }

    @Test
    public void testPerformDatabaseBackup() {
        audit.performDatabaseBackup();
        assertTrue(outContent.toString().contains("Performing database backup..."));
    }

    @Test
    public void testTrackAdminActions() {
        audit.trackAdminActions("ADMIN001", "Changed server password");
        assertTrue(outContent.toString().contains("Tracking admin action: Changed server password"));
    }

    @Test
    public void testNotifyAdminOnCriticalLogs() {
        audit.notifyAdminOnCriticalLogs();
        assertTrue(outContent.toString().contains("Notifying admin about critical system logs..."));
    }

    @Test
    public void testExportAuditData() {
        audit.exportAuditData();
        assertTrue(outContent.toString().contains("Exporting audit data..."));
    }
}
