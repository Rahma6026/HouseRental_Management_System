

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FeedbackTest {
    private Feedback feedback;
    private final String FEEDBACK_ID = "FB001";
    private final String HOUSE_ID = "H100";
    private final String OWNER_ID = "O200";
    private final String TENANT_ID = "T300";

    @Before
    public void setup() {
        feedback = new Feedback();
    }

    @Test
    public void test01SubmitValidFeedback() {
        boolean result = feedback.submitFeedback(FEEDBACK_ID, HOUSE_ID, OWNER_ID, TENANT_ID, "Great house!");
        assertTrue(result);
        Feedback.FeedbackEntry entry = feedback.getFeedback(FEEDBACK_ID);
        assertNotNull(entry);
        assertEquals("Great house!", entry.content);
    }

    @Test
    public void test02SubmitInvalidFeedback() {
        boolean result = feedback.submitFeedback(null, HOUSE_ID, OWNER_ID, TENANT_ID, "Test feedback");
        assertFalse(result);
    }

    @Test
    public void test03ViewFeedback() {
        feedback.submitFeedback(FEEDBACK_ID, HOUSE_ID, OWNER_ID, TENANT_ID, "Nice place");
        Feedback.FeedbackEntry entry = feedback.getFeedback(FEEDBACK_ID);
        assertNotNull(entry);
        assertEquals("New", entry.status);
        assertEquals("Nice place", entry.content);
    }

    @Test
    public void test04UpdateFeedbackStatus() {
        feedback.submitFeedback(FEEDBACK_ID, HOUSE_ID, OWNER_ID, TENANT_ID, "Needs improvement");
        boolean result = feedback.updateStatus(FEEDBACK_ID, "Resolved");
        assertTrue(result);
        Feedback.FeedbackEntry entry = feedback.getFeedback(FEEDBACK_ID);
        assertEquals("Resolved", entry.status);
    }

    @Test
    public void test05AddReplyToFeedback() {
        feedback.submitFeedback(FEEDBACK_ID, HOUSE_ID, OWNER_ID, TENANT_ID, "Request repair");
        boolean result = feedback.addReply(FEEDBACK_ID, "We will fix it tomorrow.");
        assertTrue(result);
        Feedback.FeedbackEntry entry = feedback.getFeedback(FEEDBACK_ID);
        assertEquals("We will fix it tomorrow.", entry.reply);
    }

    @Test
    public void test06DeleteFeedback() {
        feedback.submitFeedback(FEEDBACK_ID, HOUSE_ID, OWNER_ID, TENANT_ID, "Temporary issue");
        boolean result = feedback.deleteFeedback(FEEDBACK_ID);
        assertTrue(result);
        assertNull(feedback.getFeedback(FEEDBACK_ID));
    }

    @Test
    public void test07ValidRating() {
        boolean result = feedback.rate(HOUSE_ID, 4);
        assertTrue(result);
        double rating = feedback.getAverageRating(HOUSE_ID);
        assertEquals(4.0, rating, 0.001);
    }

    @Test
    public void test08InvalidRatingLow() {
        boolean result = feedback.rate(HOUSE_ID, 0);
        assertFalse(result);
    }

    @Test
    public void test09InvalidRatingHigh() {
        boolean result = feedback.rate(HOUSE_ID, 6);
        assertFalse(result);
    }

    @Test
    public void test10GetAverageRatingForUnratedEntity() {
        double rating = feedback.getAverageRating("UNKNOWN");
        assertEquals(0.0, rating, 0.001);
    }

    @Test
    public void test11PositiveFeedbackDetection() {
        feedback.submitFeedback("FB100", HOUSE_ID, OWNER_ID, TENANT_ID, "Excellent support and good ambiance");
        List<Feedback.FeedbackEntry> positives = feedback.getPositiveFeedback();
        assertEquals(1, positives.size());
        assertEquals("Excellent support and good ambiance", positives.get(0).content);
    }

    @Test
    public void test12NegativeFeedbackDetection() {
        feedback.submitFeedback("FB200", HOUSE_ID, OWNER_ID, TENANT_ID, "Bad experience and poor hygiene");
        List<Feedback.FeedbackEntry> negatives = feedback.getNegativeFeedback();
        assertEquals(1, negatives.size());
        assertEquals("Bad experience and poor hygiene", negatives.get(0).content);
    }

    @Test
    public void test13GetNonExistentFeedback() {
        Feedback.FeedbackEntry entry = feedback.getFeedback("INVALID_ID");
        assertNull(entry);
    }

    @Test
    public void test14UpdateStatusInvalidFeedback() {
        boolean result = feedback.updateStatus("NON_EXIST", "Closed");
        assertFalse(result);
    }

    @Test
    public void test15AddReplyInvalidFeedback() {
        boolean result = feedback.addReply("NON_EXIST", "Reply here");
        assertFalse(result);
    }

    @Test
    public void test16DeleteInvalidFeedback() {
        boolean result = feedback.deleteFeedback("NON_EXIST");
        assertFalse(result);
    }

    @Test
    public void test17MultipleRatingsOverwrite() {
        feedback.rate(HOUSE_ID, 3);
        feedback.rate(HOUSE_ID, 5);  //overwrite
        double rating = feedback.getAverageRating(HOUSE_ID);
        assertEquals(5.0, rating, 0.001);
    }

    @Test
    public void test18SubmitEmptyContent() {
        boolean result = feedback.submitFeedback("FB999", HOUSE_ID, OWNER_ID, TENANT_ID, "");
        assertTrue(result);  // Allowed by logic // empty feedback
        Feedback.FeedbackEntry entry = feedback.getFeedback("FB999");
        assertEquals("", entry.content);
    }
}
