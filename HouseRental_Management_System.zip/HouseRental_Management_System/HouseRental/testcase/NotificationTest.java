

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class NotificationTest {

    private Notification notification;

    @Before
    public void setUp() {
        Notification.getNotificationLog().clear();
        notification = new Notification("user123", "Welcome!", "EMAIL");
    }

    @After
    public void tearDown() {
        Notification.getNotificationLog().clear();
    }

    @Test
    public void testNotificationCreation() {
        assertEquals(1, Notification.getNotificationLog().size());
   
    }

    @Test
    public void testSendSMSNotification() {
        Notification sms = new Notification("user123", "SMS Message", "SMS");
        sms.sendSMSNotification();
        assertEquals("SMS", sms.getType());
    }

    @Test
    public void testSendPushNotification() {
        Notification push = new Notification("user123", "Push Message", "PUSH");
        push.sendPushNotification();
        assertEquals("PUSH", push.getType());
    }

    @Test
    public void testCreateNotification() {
        notification.createNotification("New Message", "EMAIL");
        assertEquals(2, Notification.getNotificationLog().size());
      
    }

    @Test
    public void testDeleteNotification() {
        String id = notification.getNotificationId();
        notification.deleteNotification(id);
        assertEquals(0, Notification.getNotificationLog().size());
    }

    @Test
    public void testUpdateNotificationSettings() {
        notification.updateNotificationSettings("PUSH");
        assertEquals("PUSH", notification.getType());
    }

    @Test
    public void testMarkAsReadUnread() {
        notification.markAsRead();
        assertTrue(notification.isRead());

        notification.markAsUnread();
        assertFalse(notification.isRead());
    }

    @Test
    public void testScheduleNotification() {
        Date future = new Date(System.currentTimeMillis() + 10000);
        notification.scheduleNotification(future);
    }

    @Test
    public void testSchedulePastNotification() {
        Date past = new Date(System.currentTimeMillis() - 10000);
        notification.scheduleNotification(past);
               assertEquals(1, Notification.getNotificationLog().size());
    }

    @Test
    public void testResendArchivedNotification() {
        notification.archiveNotification();
        notification.resendNotification();
                assertEquals(1, Notification.getNotificationLog().size());
    }


    @Test
    public void testArchiveNotification() {
        notification.archiveNotification();
        assertTrue(notification.isArchived());
    }

    @Test
    public void testNotifyOnPaymentDue() {
        Date dueDate = new Date(System.currentTimeMillis() + 86400000); 
        notification.notifyOnPaymentDue(500.0, dueDate);

        List<Notification> logs = Notification.getNotificationLog();
        assertEquals(2, logs.size());
    }

    @Test
    public void testCreateNotificationWithNullMessage() {
        Notification nullMessage = new Notification("user123", null, "EMAIL");
        assertNull(nullMessage.getMessage1());
    }

    @Test
    public void testCreateNotificationWithEmptyType() {
        Notification emptyType = new Notification("user123", "Test", "");
        assertEquals("", emptyType.getType());
    }

    @Test
    public void testDeleteNonexistentNotification() {
        notification.deleteNotification("INVALID_ID");
        assertEquals(1, Notification.getNotificationLog().size()); 
    }

    @Test
    public void testUpdateSettingsWithNull() {
        notification.updateNotificationSettings(null);
        assertNull(notification.getType());
    }
}