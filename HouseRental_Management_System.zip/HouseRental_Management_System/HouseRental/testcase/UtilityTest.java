

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class UtilityTest {

    private Utility utility;

    @Before
    public void setUp() {
        utility = new Utility();
    }

    @Test
    public void testFormatDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(2024, Calendar.DECEMBER, 25);
        String result = utility.formatDate(cal.getTime());
        assertEquals("2024-12-25", result);
    }

    @Test
    public void testFormatCurrency() {
        String formatted = utility.formatCurrency(1234.56);
        assertTrue(formatted.contains("1,234.56"));
    }

    @Test
    public void testValidateEmail() {
        assertTrue(utility.validateEmail("Mira123@gmail.com"));
        assertFalse(utility.validateEmail("invalid-email"));
    }

    @Test
    public void testValidatePhoneNumber() {
        assertTrue(utility.validatePhoneNumber("01934857575"));
        assertFalse(utility.validatePhoneNumber("12345"));
    }

    @Test
    public void testGenerateUniqueId() {
        String id1 = utility.generateUniqueId();
        String id2 = utility.generateUniqueId();
        assertNotEquals(id1, id2);
    }

    @Test
    public void testEncryptDecryptData() {
        String key = "1234567812345678"; 
        String original = "SecretMessage";
        String encrypted = utility.encryptData(original, key);
        String decrypted = utility.decryptData(encrypted, key);
        assertEquals(original, decrypted);
    }

    @Test
    public void testCalculateTax() {
        double tax = utility.calculateTax(100.0);
        assertEquals(5.0, tax, 0.001);
    }

    @Test
    public void testConvertToAndFromJSON() {
        Map<String, String> map = new HashMap<>();
        map.put("name", "Mira");
        map.put("city", "Dhaka");
        String json = utility.convertToJSON(map);
        Map<String, String> result = utility.convertFromJSON(json);
        assertEquals(map, result);
    }

    @Test
    public void testReadWriteFile() throws IOException {
        String filePath = "testFile.txt";
        String content = "Hello, File!";
        utility.writeToFile(filePath, content);
        String readContent = utility.readFromFile(filePath).trim();
        assertEquals(content, readContent);
        new File(filePath).delete();
    }

    @Test
    public void testLogError() {
        utility.logError("Test error message");
        File logFile = new File("error_log.txt");
        assertTrue(logFile.exists());
        logFile.delete();
    }

    @Test
    public void testBackupDatabase() throws IOException {
        String original = "original.txt";
        String backup = "backup.txt";
        utility.writeToFile(original, "Backup content");
        utility.backupDatabase(original, backup);
        String originalContent = utility.readFromFile(original).trim();
        String backupContent = utility.readFromFile(backup).trim();
        assertEquals(originalContent, backupContent);
        new File(original).delete();
        new File(backup).delete();
    }
}