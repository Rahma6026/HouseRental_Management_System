

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TenantTest {

    private Tenant tenant;
    private House mockHouse;

    @Before
    public void setUp() {
        tenant = new Tenant("T001", "Sahara Omi", "omi@gmail.com", "password123");
        mockHouse = new House("H001", 1500.0, "123 Main St");
    }

    @Test
    public void testUpdatePhoneNumber() {
        tenant.updatePhoneNumber("01776123951");
        assertEquals("01776123951", tenant.getPhoneNumber());
    }

    @Test
    public void testUpdatePhoneNumberWithInvalidNumber() {
        tenant.updatePhoneNumber(""); 
        assertEquals("", tenant.getPhoneNumber());
    }

    @Test
    public void testPayRentPositiveAmount() {
        tenant.payRent(2000.0); 
        
    }

    @Test
    public void testPayRentZeroAmount() {
        tenant.payRent(0.0); 
    }

    @Test
    public void testPayRentNegativeAmount() {
        tenant.payRent(-500.0); 
        }

    @Test
    public void testSendMaintenanceRequest() {
        tenant.sendMaintenanceRequest("REQ001", "Leaky faucet");
        assertTrue(tenant.getIssuesRaised().contains("Leaky faucet"));
    }


    @Test
    public void testReportNeighborIssue() {
        tenant.reportNeighborIssue("Noise complaint");
        assertTrue(tenant.getIssuesRaised().contains("Neighbor issue: Noise complaint"));
    }

    @Test
    public void testSetRentedHouse() {
        tenant.setRentedHouse(mockHouse);
        assertTrue(tenant.hasActiveLease());
        assertEquals(mockHouse, tenant.getRentedHouse());
    }

    @Test
    public void testEndLease() {
        tenant.setRentedHouse(mockHouse);
        tenant.endLease();
        assertFalse(tenant.hasActiveLease());
        assertNull(tenant.getRentedHouse());
    }

    @Test
    public void testRequestLeaseExtensionWithoutActiveLease() {
        tenant.requestLeaseExtension(); 
        assertFalse(tenant.hasActiveLease());
    }

    @Test
    public void testRequestLeaseExtensionWithActiveLease() {
        tenant.setRentedHouse(mockHouse);
        tenant.requestLeaseExtension(); 
        assertTrue(tenant.hasActiveLease());
    }

    @Test
    public void testChangePassword() {
        tenant.changePassword("newpassword123");
            }

    @Test
    public void testChangePasswordToEmpty() {
        tenant.changePassword(""); 
    }

    @Test
    public void testLogout() {
        tenant.logout(); 
    }

    @Test
    public void testSubmitFeedback() {
        tenant.submitFeedback("Great service!"); 
    }

    @Test
    public void testSubmitEmptyFeedback() {
        tenant.submitFeedback(""); 
    }

    @Test
    public void testViewProfile() {
        tenant.updatePhoneNumber("01915623383");
        tenant.viewProfile(); 
    }

    @Test
    public void testViewIssues() {
        tenant.sendMaintenanceRequest("REQ002", "AC not working");
        tenant.viewIssues(); 
    }

    @Test
    public void testViewAvailableProperties() {
        tenant.viewAvailableProperties(); 
    }

    @Test
    public void testGetters() {
        assertEquals("T001", tenant.getTenantId());
        assertEquals("Sahara Omi", tenant.getName());
        assertEquals("omi@gmail.com", tenant.getEmail());
    }

    @Test
    public void testSetNullHouseAsLease() {
        tenant.setRentedHouse(null);
        assertNull(tenant.getRentedHouse());
    }
}