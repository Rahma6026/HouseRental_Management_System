

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ContractTest {
    private Contract contract;
    private final String ID = "CTR001";
    private final String DETAILS = "Standard 1-year lease";
    private final String TENANT = "Jabatun Nessa";
    private final String OWNER = "Omi";

    @Before
    public void setup() {
        contract = new Contract();
    }

    @Test
    public void test01CreateContract() {
        boolean result1 = contract.createContract(ID, DETAILS);
        boolean result2 = contract.createContract(ID, DETAILS); 
        boolean result3 = contract.createContract("", DETAILS); 

        assertEquals(true, result1);
        assertEquals(false, result2);
        assertEquals(false, result3);
    }

    @Test
    public void test02SignContract() {
        contract.createContract(ID, DETAILS);
        boolean result1 = contract.signContract(ID);
        boolean result2 = contract.isSigned(ID);

        assertEquals(true, result1);
        assertEquals(true, result2);
    }

    @Test
    public void test03AssignToTenant() {
        contract.createContract(ID, DETAILS);
        boolean result = contract.assignToTenant(ID, TENANT);
        String assigned = contract.getAssignedTenant(ID);

        assertEquals(true, result);
        assertEquals(TENANT, assigned);
    }

    @Test
    public void test04SendToOwner() {
        contract.createContract(ID, DETAILS);
        boolean result = contract.sendToOwner(ID, OWNER);
        String owner = contract.getOwner(ID);

        assertEquals(true, result);
        assertEquals(OWNER, owner);
    }

    @Test
    public void test05RemoveContract() {
        contract.createContract(ID, DETAILS);
        boolean result = contract.removeContract(ID);
        boolean exists = contract.contractExists(ID);

        assertEquals(true, result);
        assertEquals(false, exists);
    }

    @Test
    public void test06NonExistentContract() {
        boolean result = contract.signContract("NON_EXISTENT");
        String tenant = contract.getAssignedTenant("NON_EXISTENT");

        assertEquals(false, result);
        assertEquals(null, tenant);
    }

    @Test
    public void test07ContractValidation() {
        boolean result1 = contract.createContract("", "");
        boolean result2 = contract.createContract(null, DETAILS);

        assertEquals(false, result1);
        assertEquals(false, result2);
    }

    @Test
    public void test08UpdateContract() {
        contract.createContract(ID, DETAILS);
        String newDetails = "Updated lease terms";
        boolean result = contract.updateContract(ID, newDetails);
        String updated = contract.getContractDetails(ID);

        assertEquals(true, result);
        assertEquals(newDetails, updated);
    }

    @Test
    public void test09ContractDetails() {
        contract.createContract(ID, DETAILS);
        String details = contract.getContractDetails(ID);

        assertEquals(DETAILS, details);
    }

    @Test
    public void test10EmptyTenantAssignment() {
        contract.createContract(ID, DETAILS);
        boolean result = contract.assignToTenant(ID, "");
        String tenant = contract.getAssignedTenant(ID);

        assertEquals(false, result);
        assertEquals(null, tenant);
    }

    @Test
    public void test11MultipleOperations() {
        contract.createContract(ID, DETAILS);
        contract.signContract(ID);
        contract.assignToTenant(ID, TENANT);
        contract.sendToOwner(ID, OWNER);

        assertEquals(true, contract.contractExists(ID));
        assertEquals(true, contract.isSigned(ID));
        assertEquals(TENANT, contract.getAssignedTenant(ID));
        assertEquals(OWNER, contract.getOwner(ID));
    }

    @Test
    public void test12InvalidOperations() {
        assertEquals(false, contract.updateContract("INVALID", DETAILS));
        assertEquals(false, contract.removeContract("INVALID"));
        assertEquals(false, contract.assignToTenant("INVALID", TENANT));
    }


    @Test
    public void test13DuplicateTenantAssignment() {
        contract.createContract(ID, DETAILS);
        contract.assignToTenant(ID, TENANT);
        boolean result = contract.assignToTenant(ID, "New Tenant");

        assertEquals(true, result);
        assertEquals("New Tenant", contract.getAssignedTenant(ID));
    }

    @Test
    public void test14ReSignContract() {
        contract.createContract(ID, DETAILS);
        contract.signContract(ID);
        boolean result = contract.signContract(ID); // sign again

        assertEquals(true, result);
        assertEquals(true, contract.isSigned(ID));
    }

    @Test
    public void test15NullAssignments() {
        contract.createContract(ID, DETAILS);
        boolean result1 = contract.assignToTenant(ID, null);
        boolean result2 = contract.sendToOwner(ID, null);

        assertEquals(false, result1);
        assertEquals(false, result2);
    }

    @Test
    public void test16GetDetailsAfterRemoval() {
        contract.createContract(ID, DETAILS);
        contract.removeContract(ID);
        String details = contract.getContractDetails(ID);

        assertEquals(null, details);
    }
}
