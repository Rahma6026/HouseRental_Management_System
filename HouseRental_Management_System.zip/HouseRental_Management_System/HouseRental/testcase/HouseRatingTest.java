

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Map;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class HouseRatingTest {
    private HouseRating ratings;
    private final String HOUSE1 = "H001";
    private final String HOUSE2 = "H002";
    private final String HOUSE3 = "H003";
    private final String HOUSE4 = "H004";

    @Before
    public void setup() {
        ratings = new HouseRating();
    }

    @Test
    public void test01SubmitRating() {
        boolean result = ratings.rateHouse(HOUSE1, 5);
        assertTrue(result);
        assertEquals(1, ratings.getRatingCount(HOUSE1));
        assertEquals(5.0, ratings.getAverageRating(HOUSE1), 0.01);

        result = ratings.rateHouse(HOUSE1, 6); // invalid
        assertFalse(result);
        assertEquals(1, ratings.getRatingCount(HOUSE1));
        assertEquals(5.0, ratings.getAverageRating(HOUSE1), 0.01);
    }

    @Test
    public void test02MultipleRatings() {
        ratings.rateHouse(HOUSE2, 4);
        ratings.rateHouse(HOUSE2, 5);
        assertEquals(2, ratings.getRatingCount(HOUSE2));
        assertEquals(4.5, ratings.getAverageRating(HOUSE2), 0.01);
    }

    @Test
    public void test03RemoveRating() {
        ratings.rateHouse(HOUSE3, 3);
        boolean removed = ratings.removeRating(HOUSE3);
        assertTrue(removed);
        assertNull(ratings.getRating(HOUSE3));
        assertEquals(0, ratings.getRatingCount(HOUSE3));
    }

    @Test
    public void test04MostRatedHouse() {
        ratings.rateHouse(HOUSE1, 4);
        ratings.rateHouse(HOUSE1, 5);
        ratings.rateHouse(HOUSE2, 3);
        String mostRated = ratings.getMostRatedHouse();
        assertEquals(HOUSE1, mostRated);
    }

    @Test
    public void test05HousesWithRating() {
        ratings.rateHouse(HOUSE1, 5);
        ratings.rateHouse(HOUSE2, 5);
        ratings.rateHouse(HOUSE3, 4);

        Map<String, Double> fiveStarHouses = ratings.getHousesWithRating(5);
        assertEquals(2, fiveStarHouses.size());
        assertTrue(fiveStarHouses.containsKey(HOUSE1));
        assertTrue(fiveStarHouses.containsKey(HOUSE2));
    }

    @Test
    public void test06GetAllRatings() {
        ratings.rateHouse(HOUSE1, 4);
        ratings.rateHouse(HOUSE2, 5);
        ratings.rateHouse(HOUSE3, 3);

        Map<String, Double> allRatings = ratings.getAllRatedHouses();
        assertEquals(3, allRatings.size());
        assertEquals(4.0, allRatings.get(HOUSE1), 0.01);
        assertEquals(5.0, allRatings.get(HOUSE2), 0.01);
        assertEquals(3.0, allRatings.get(HOUSE3), 0.01);
    }

    @Test
    public void test07LowRatingHouses() {
        ratings.rateHouse(HOUSE1, 2);
        ratings.rateHouse(HOUSE2, 1);

        Map<String, Double> lowRatedHouses = ratings.getHousesWithRating(1);
        assertEquals(1, lowRatedHouses.size());
        assertEquals(1.0, lowRatedHouses.get(HOUSE2), 0.01);
    }

    @Test
    public void test08ConsistentRating() {
        ratings.rateHouse(HOUSE4, 4);
        ratings.rateHouse(HOUSE4, 4);
        ratings.rateHouse(HOUSE4, 4);
        Double avg = ratings.getAverageRating(HOUSE4);
        assertEquals(4.0, avg, 0.01);
        assertEquals(3, ratings.getRatingCount(HOUSE4));
    }

    @Test
    public void test09RatingBoundaries() {
        boolean resultLow = ratings.rateHouse(HOUSE1, 0);
        boolean resultHigh = ratings.rateHouse(HOUSE1, 6);
        boolean resultValid1 = ratings.rateHouse(HOUSE1, 1);
        boolean resultValid5 = ratings.rateHouse(HOUSE1, 5);

        assertFalse(resultLow);
        assertFalse(resultHigh);
        assertTrue(resultValid1);
        assertTrue(resultValid5);
        assertEquals(2, ratings.getRatingCount(HOUSE1));
        assertEquals(3.0, ratings.getAverageRating(HOUSE1), 0.01);
    }

    @Test
    public void test10NonExistentHouse() {
        String house = "H999";
        assertEquals(0, ratings.getRatingCount(house));
        assertNull(ratings.getRating(house));
        assertNull(ratings.getAverageRating(house));
        assertFalse(ratings.removeRating(house));
    }

    @Test
    public void test11RoundingEffectInFiltering() {
        ratings.rateHouse(HOUSE1, 4);
        ratings.rateHouse(HOUSE1, 5); // avg = 4.5, rounded = 5
        ratings.rateHouse(HOUSE2, 4);
        ratings.rateHouse(HOUSE2, 4); // avg = 4.0, rounded = 4
        Map<String, Double> roundedFive = ratings.getHousesWithRating(5);
        assertEquals(1, roundedFive.size());
        assertEquals(4.5, roundedFive.get(HOUSE1), 0.01);
    }
}
