

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class UserProfileTest {
    private UserProfile userProfile;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private PrintStream originalOut;

    @Before
    public void setUp() {
        originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        userProfile = new UserProfile("user123", "Rahma Adithi", "rahma1234@gmail.com", "01331034751");

        userProfile.createProfile();
        clearOutput(); 
    }

    @After
    public void tearDown() {
        System.setOut(originalOut);
    }

    /** Helper to fetch trimmed console output */
    private String output() {
        return outContent.toString().trim();
    }

    /** Helper to clear captured output */
    private void clearOutput() {
        outContent.reset();
    }

    /** Test Cases **/

    @Test
    public void testGetAndSetUserId() {
        assertEquals("user123", userProfile.getUserId());
        userProfile.setUserId("newId456");
        assertEquals("newId456", userProfile.getUserId());
    }

    @Test
    public void testCreateProfile() {
        userProfile.createProfile();
        assertTrue(output().contains("Profile created for: Rahma Adithi"));
    }

    @Test
    public void testUpdateProfile() {
        userProfile.updateProfile("Rahma Mahbub", "rahmamahbub@gmail.com", "01331034751");
        assertTrue(output().contains("Profile updated for: Rahma Mahbub"));
    }

    @Test
    public void testViewProfile() {
        userProfile.viewProfile();
        String out = output();
        assertTrue(out.contains("User Profile Details:"));
        assertTrue(out.contains("User ID: user123"));
        assertTrue(out.contains("Name: Rahma Adithi"));
        assertTrue(out.contains("Email: rahma1234@gmail.com"));
        assertTrue(out.contains("Phone: 01331034751"));
        assertTrue(out.contains("Profile Picture: null"));
    }

    @Test
    public void testDeleteProfile() {
        userProfile.deleteProfile();
        assertTrue(output().contains("Profile deleted for: Rahma Adithi"));
    }

    @Test
    public void testUploadProfilePicture() {
        userProfile.uploadProfilePicture("avatar.png");
        assertTrue(output().contains("Profile picture uploaded for: Rahma Adithi"));
    }

    @Test
    public void testChangeProfileSettings() {
        userProfile.changeProfileSettings("Theme", "Dark");
        assertTrue(output().contains("Profile setting Theme changed to: Dark"));
    }

    @Test
    public void testViewTransactionHistory_Empty() {
        userProfile.viewTransactionHistory();
        assertTrue(output().contains("No transaction history available."));
    }

    @Test
    public void testUpdateSecuritySettings() {
        userProfile.updateSecuritySettings("2FA", "Enabled");
        assertTrue(output().contains("Security setting updated to: 2FA: Enabled"));
    }

    @Test
    public void testSendProfileInvite() {
        userProfile.sendProfileInvite("Omi@gmail.com");
        assertTrue(output().contains("Profile invite sent to: Omi@gmail.com"));
    }

    @Test
    public void testViewProfileStatistics_Empty() {
        userProfile.viewProfileStatistics();
        String out = output();
        assertTrue(out.contains("Profile Statistics for: Rahma Adithi"));
        assertTrue(out.contains("Number of Properties: 1"));
        assertTrue(out.contains("Number of Transactions: 0"));
        assertTrue(out.contains("Number of Feedbacks: 0"));
    }

    @Test
    public void testBlockUser() {
        userProfile.blockUser("user456");
        assertTrue(output().contains("User user456 has been blocked."));
    }

    @Test
    public void testViewUserNotifications_Empty() {
        userProfile.viewUserNotifications();
        assertTrue(output().contains("No notifications available."));
    }

    @Test
    public void testListUserProperties_Empty() {
        userProfile.listUserProperties();
        assertTrue(output().contains("No properties listed."));
    }

    @Test
    public void testViewUserFeedback_Empty() {
        userProfile.viewUserFeedback();
        assertTrue(output().contains("No feedback available."));
    }

    @Test
    public void testConstructorInitialization() {
        assertEquals("user123", userProfile.getUserId());
    }

    @Test
    public void testDefaultProfilePictureIsNull() {
        userProfile.viewProfile();
        assertTrue(output().contains("Profile Picture: null"));
    }

    @Test
    public void testDefaultTransactionHistoryIsEmpty() {
        userProfile.viewTransactionHistory();
        assertTrue(output().contains("No transaction history available."));
    }

    @Test
    public void testDefaultNotificationsIsEmpty() {
        userProfile.viewUserNotifications();
        assertTrue(output().contains("No notifications available."));
    }

    @Test
    public void testDefaultPropertiesIsEmpty() {
        userProfile.listUserProperties();
        assertTrue(output().contains("No properties listed."));
    }

    @Test
    public void testDefaultFeedbackIsEmpty() {
        userProfile.viewUserFeedback();
        assertTrue(output().contains("No feedback available."));
    }
}
