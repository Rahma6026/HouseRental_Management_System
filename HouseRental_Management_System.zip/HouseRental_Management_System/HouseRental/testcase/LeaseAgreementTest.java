

import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class LeaseAgreementTest {

    private LeaseAgreement agreement;

    @Before
    public void setUp() {
        agreement = new LeaseAgreement("H001", "T001", "O001");
    }

    @Test
    public void testAgreementCreation() {
        assertNotNull(agreement.getAgreementId());
        assertFalse(agreement.isSigned());
        assertFalse(agreement.isTerminated());
        assertFalse(agreement.isArchived());
    }

    @Test
    public void testSignAgreement() {
        agreement.signAgreement();
        assertTrue(agreement.isSigned());
    }

    @Test
    public void testSignTerminatedAgreement() {
        agreement.terminateAgreement();
        agreement.signAgreement();
        assertFalse(agreement.isSigned());
    }

    @Test
    public void testSignArchivedAgreement() {
        agreement.archiveAgreement();
        agreement.signAgreement();
        assertFalse(agreement.isSigned());
    }

    @Test
    public void testUpdateArchivedAgreement() {
        agreement.archiveAgreement();
        agreement.updateAgreement("New Content");
        assertNotEquals("New Content", agreement.getAgreementId());
    }

    @Test
    public void testTerminateAgreement() {
        agreement.terminateAgreement();
        assertTrue(agreement.isTerminated());
    }


    @Test
    public void testRenewTerminatedAgreement() {
        agreement.terminateAgreement();
        Date futureDate = new Date(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(30));
        agreement.renewAgreement(futureDate);
        assertNull(agreement.getEndDate());
    }

    @Test
    public void testVerifyAgreementValid() {
        agreement.createAgreement("Terms");
        agreement.signAgreement();
        assertTrue(agreement.verifyAgreement());
    }


    @Test
    public void testArchiveAgreement() {
        agreement.archiveAgreement();
        assertTrue(agreement.isArchived());
    }

    @Test
    public void testDoubleTermination() {
        agreement.terminateAgreement();
        agreement.terminateAgreement(); 
        assertTrue(agreement.isTerminated());
    }

    @Test
    public void testCheckAgreementValidity_valid() throws InterruptedException {
        Date now = new Date();
        Date later = new Date(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(5));
        agreement.setStartDate(now);
        agreement.setEndDate(later);
        agreement.signAgreement();

        agreement.checkAgreementValidity(); 
    }

    @Test
    public void testCheckAgreementValidity_notSigned() {
        Date now = new Date();
        Date later = new Date(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(5));
        agreement.setStartDate(now);
        agreement.setEndDate(later);

        agreement.checkAgreementValidity(); 
    }


    @Test
    public void testDownloadAgreement() {
        agreement.createAgreement("Download Test");
        agreement.downloadAgreement();
    }

    @Test
    public void testStoreAgreement() {
        agreement.storeAgreement();     }

    @Test
    public void testNotifyParties() {
        agreement.notifyParties(); 
    }

    @Test
    public void testGetAgreementDetails() {
        agreement.getAgreementDetails(); 
    }

    @Test
    public void testViewAgreement() {
        agreement.viewAgreement(); 
    }

    @Test
    public void testGenerateAgreementIdUniqueness() {
        LeaseAgreement a2 = new LeaseAgreement("H002", "T002", "O002");
        assertNotEquals(agreement.getAgreementId(), a2.getAgreementId());
    }

    
}