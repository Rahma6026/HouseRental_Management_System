

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class OwnerTest {
    private Owner owner;
    private House house;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void setUp() {
        owner = new Owner("Rahma Mahbub", "rahmamahbub@gmail.com");
        house = new House("House1", 1000, "123 Main St");
        owner.addHouseToOwner(house);
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void tearDown() {
        System.setOut(originalOut);  
        outContent.reset();          
    }

    private String getOutput() {
        return outContent.toString().trim();
    }

    @Test
    public void testRegisterOwner() {
        owner.registerOwner();
        assertTrue(getOutput().contains("Owner registered: Rahma Mahbub"));
    }

    @Test
    public void testLoginOwner_Success() {
        owner.changePassword("ownerPassword");
        outContent.reset();
        owner.loginOwner("rahmamahbub@gmail.com", "ownerPassword");
        assertTrue(getOutput().contains("Owner logged in successfully: Rahma Mahbub"));
    }

    @Test
    public void testLoginOwner_Failure() {
        owner.loginOwner("wrongEmail@gmail.com", "wrongPassword");
        assertTrue(getOutput().contains("Invalid credentials for owner: Rahma Mahbub"));
    }

    @Test
    public void testUpdateOwnerProfile() {
        owner.updateOwnerProfile("Rahma Mahbub", "123-456-7890");
        assertTrue(getOutput().contains("Owner profile updated: Rahma Mahbub"));
    }

    @Test
    public void testDeleteOwnerAccount() {
        owner.deleteOwnerAccount();
        assertTrue(getOutput().contains("Owner account deleted: Rahma Mahbub"));
    }

    @Test
    public void testListOwnerHouses() {
        owner.listOwnerHouses();
        assertTrue(getOutput().contains("Listing owned houses for Rahma Mahbub:"));
        assertTrue(getOutput().contains(house.getHouseId()));
    }

    @Test
    public void testAssignHouseToTenant_Success() {
        owner.assignHouseToTenant(house, "Omi");
        assertTrue(getOutput().contains("House " + house.getHouseId() + " assigned to tenant: Omi"));
    }

    @Test
    public void testAssignHouseToTenant_Failure() {
        House nonOwnedHouse = new House("House2", 1200, "456 Oak St");
        owner.assignHouseToTenant(nonOwnedHouse, "Nessa");
        assertTrue(getOutput().contains("This house does not belong to owner: Rahma Mahbub"));
    }

    @Test
    public void testReceiveRent() {
        owner.receiveRent(house, 1000);
        assertTrue(getOutput().contains("Received rent of $1000.0 for house " + house.getHouseId()));
    }

    @Test
    public void testViewTransactionHistory() {
        owner.receiveRent(house, 1000);
        outContent.reset();
        owner.viewTransactionHistory();
        assertTrue(getOutput().contains("Transaction history for Rahma Mahbub:"));
        assertTrue(getOutput().contains("Received rent of $1000.0"));
    }

    @Test
    public void testChangePassword() {
        owner.changePassword("newPassword");
        assertTrue(getOutput().contains("Password changed successfully for owner: Rahma Mahbub"));
    }

    @Test
    public void testViewOwnerDetails() {
        owner.viewOwnerDetails();
        assertTrue(getOutput().contains("Owner Details:"));
        assertTrue(getOutput().contains("Name: Rahma Mahbub"));
        assertTrue(getOutput().contains("Email: rahmamahbub@gmail.com"));
    }

    @Test
    public void testApproveHouseListing() {
        owner.approveHouseListing(house);
        assertTrue(getOutput().contains("House listing approved for: " + house.getHouseId()));
    }

    @Test
    public void testUploadOwnerDocuments() {
        owner.uploadOwnerDocuments("OwnershipDoc");
        assertTrue(getOutput().contains("Document uploaded: OwnershipDoc for owner: Rahma Mahbub"));
    }

    @Test
    public void testVerifyOwnership_Success() {
        owner.verifyOwnership(house);
        assertTrue(getOutput().contains("Ownership verified for house: " + house.getHouseId()));
    }

    @Test
    public void testVerifyOwnership_Failure() {
        House nonOwnedHouse = new House("House2", 1200, "456 Oak St");
        owner.verifyOwnership(nonOwnedHouse);
        assertTrue(getOutput().contains("House " + nonOwnedHouse.getHouseId() + " does not belong to owner: Rahma Mahbub"));
    }

    @Test
    public void testMessageTenant() {
        owner.messageTenant("Nessa", "Reminder: Rent due.");
        assertTrue(getOutput().contains("Message sent to tenant Nessa: Reminder: Rent due."));
    }

    @Test
    public void testGetRentalAnalytics() {
        House rentedHouse = new House("House3", 1500, "789 Pine St");
        rentedHouse.markHouseAsRented();
        owner.addHouseToOwner(rentedHouse);
        owner.getRentalAnalytics();
        assertTrue(getOutput().contains("Total rent collected from rented houses: $1500.0"));
    }
    
    @Test
    public void testAddHouseToOwner() {
        House newHouse = new House("House4", 1100, "99 River Rd");
        owner.addHouseToOwner(newHouse);
        assertTrue(owner.getOwnedHouses().contains(newHouse));
        assertTrue(getOutput().contains("House " + newHouse.getHouseId() + " added to owner Rahma Mahbub"));
    }
    
    @Test
    public void testListProperty() {
        owner.listProperty("PROP1234");
        assertTrue(getOutput().contains("Property listed with ID: PROP1234 by owner Rahma Mahbub"));
    }

    @Test
    public void testViewFeedback_Empty() {
        owner.viewFeedback();
        assertTrue(getOutput().contains("No feedback available."));
    }

    @Test
    public void testViewFeedback_WithFeedback() {
        owner.receiveFeedback("Great landlord!");
        outContent.reset();
        owner.viewFeedback();
        assertTrue(getOutput().contains("Feedback for owner Rahma Mahbub:"));
        assertTrue(getOutput().contains("Great landlord!"));
    }

    @Test
    public void testViewProperties() {
        owner.viewProperties();
        assertTrue(getOutput().contains("Properties owned by Rahma Mahbub:"));
        assertTrue(getOutput().contains(house.getHouseId()));
        assertTrue(getOutput().contains(house.getAddress()));
    }

    @Test
    public void testReceiveFeedback() {
        owner.receiveFeedback("Very responsive and helpful!");
        owner.viewFeedback(); // to validate feedback was added
        assertTrue(getOutput().contains("Very responsive and helpful!"));
    }
    @Test
    public void testGetOwnerId() {
        assertNotNull(owner.getOwnerId());
        assertEquals(8, owner.getOwnerId().length());
    }

   
}
