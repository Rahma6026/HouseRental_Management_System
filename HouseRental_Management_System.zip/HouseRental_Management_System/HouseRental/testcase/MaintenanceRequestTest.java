

import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.Assert.*;

public class MaintenanceRequestTest {

    private MaintenanceRequest maintenanceRequest;
    private final String requestId = "REQ1001";

    @Before
    public void setUp() {
        maintenanceRequest = new MaintenanceRequest();
        maintenanceRequest.createMaintenanceRequest(requestId, "Power outage");
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> getFieldMap(String fieldName) throws Exception {
        Field field = MaintenanceRequest.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return (Map<String, String>) field.get(maintenanceRequest);
    }

    @Test
    public void testCreateMaintenanceRequest() throws Exception {
        Map<String, String> maintenanceMap = getFieldMap("maintenanceRequests");
        assertTrue(maintenanceMap.containsKey(requestId));
        assertEquals("Pending", maintenanceMap.get(requestId));
    }

    @Test
    public void testAssignTechnician() throws Exception {
        maintenanceRequest.assignTechnician(requestId, "Mike");
        Map<String, String> techMap = getFieldMap("techniciansAssigned");
        assertEquals("Mike", techMap.get(requestId));
    }
    
    @Test
    public void testAssignTechnicianInvalidRequest() throws Exception {
        maintenanceRequest.assignTechnician("INVALID", "Simrin");
        Map<String, String> techMap = getFieldMap("techniciansAssigned");
        assertFalse(techMap.containsKey("INVALID"));
    }

    @Test
    public void testUpdateRequestStatus() throws Exception {
        maintenanceRequest.updateRequestStatus(requestId, "In Progress");
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertEquals("In Progress", statusMap.get(requestId));
    }

    @Test
    public void testUpdateRequestStatusInvalidRequest() throws Exception {
        maintenanceRequest.updateRequestStatus("UNKNOWN", "In Progress");
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertNull(statusMap.get("UNKNOWN"));
    }

    @Test
    public void testResolveMaintenanceIssue() throws Exception {
        maintenanceRequest.resolveMaintenanceIssue(requestId);
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertEquals("Resolved", statusMap.get(requestId));
    }

    @Test
    public void testResolveInvalidRequest() throws Exception {
        maintenanceRequest.resolveMaintenanceIssue("FAKE_ID");
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertNull(statusMap.get("FAKE_ID"));
    }

    @Test
    public void testEstimateMaintenanceCost() throws Exception {
        maintenanceRequest.estimateMaintenanceCost(requestId, 180.50);
        Map<String, String> costMap = getFieldMap("maintenanceCosts");
        assertEquals("180.5", costMap.get(requestId)); 
    }

    @Test
    public void testEstimateMaintenanceCostInvalidRequest() throws Exception {
        maintenanceRequest.estimateMaintenanceCost("INVALID", 100.00);
        Map<String, String> costMap = getFieldMap("maintenanceCosts");
        assertNull(costMap.get("INVALID"));
    }

    @Test
    public void testCancelMaintenanceRequest() throws Exception {
        maintenanceRequest.cancelMaintenanceRequest(requestId);
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        Map<String, String> techMap = getFieldMap("techniciansAssigned");
        Map<String, String> costMap = getFieldMap("maintenanceCosts");

        assertFalse(statusMap.containsKey(requestId));
        assertFalse(techMap.containsKey(requestId));
        assertFalse(costMap.containsKey(requestId));
    }

    @Test
    public void testCancelNonexistentRequest() throws Exception {
        maintenanceRequest.cancelMaintenanceRequest("NON_EXISTENT");
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertFalse(statusMap.containsKey("NON_EXISTENT"));
    }

    @Test
    public void testArchiveCompletedRequest() throws Exception {
        maintenanceRequest.updateRequestStatus(requestId, "Resolved");
        maintenanceRequest.archiveCompletedRequest(requestId);
               Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertEquals("Resolved", statusMap.get(requestId));
    }

    @Test
    public void testArchiveUnresolvedRequest() throws Exception {
        maintenanceRequest.archiveCompletedRequest(requestId); 
        Map<String, String> statusMap = getFieldMap("maintenanceRequests");
        assertEquals("Pending", statusMap.get(requestId));
    }

    @Test
    public void testTrackMaintenanceRequestWithTechnician() throws Exception {
        maintenanceRequest.assignTechnician(requestId, "Sam");
        maintenanceRequest.trackMaintenanceRequest(requestId); 
            }

    @Test
    public void testScheduleMaintenanceForExistingRequest() {
        maintenanceRequest.scheduleMaintenance(requestId, "2025-06-20");
    }

    @Test
    public void testRequestApprovalForExistingRequest() {
        maintenanceRequest.requestMaintenanceApproval(requestId); 
    }

    @Test
    public void testNotifyTenantOnStatus() {
        maintenanceRequest.notifyTenantOnMaintenanceStatus(requestId); 
    }

    @Test
    public void testLogMaintenanceDetails() {
        maintenanceRequest.logMaintenanceDetails(requestId, "Work completed."); 
    }

    @Test
    public void testLogDetailsInvalidRequest() {
        maintenanceRequest.logMaintenanceDetails("INVALID", "N/A");
    }
}










































