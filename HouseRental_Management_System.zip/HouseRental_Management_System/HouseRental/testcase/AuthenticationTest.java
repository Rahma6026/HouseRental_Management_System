

import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.Assert.*;

public class AuthenticationTest {
    private Authentication authentication;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    @Before
    public void setUp() {
        authentication = new Authentication();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void testLoginUser_Success() {
        authentication.userCredentials.put("Rahma", "password123");

        // Perform login
        authentication.loginUser("Rahma", "password123");

        assertTrue(outContent.toString().contains("✅ Login successful for user: Rahma"));
    }

    @Test
    public void testLoginUser_Failure() {
        authentication.userCredentials.put("Rahma", "password123");

        // Perform failed login
        authentication.loginUser("Rahma", "wrongPassword");

        assertTrue(outContent.toString().contains("❌ Invalid credentials."));
    }

    @Test
    public void testBlockUser() {
        authentication.loginAttempts.put("Rahma", 5);
        authentication.blockUser("Rahma");

        assertTrue(outContent.toString().contains("🔒 User Rahma has been blocked."));
    }

    @Test
    public void testSendOtp() {
        authentication.sendOtp("Rahma");

        assertTrue(outContent.toString().contains("🔐 OTP for Rahma:"));
    }

    @Test
    public void testValidateOtp_Success() {
        // Send OTP first
        authentication.sendOtp("Rahma");

        
        String otp = authentication.otpMap.get("Rahma");

        // Validate OTP
        authentication.validateOtp("Rahma", otp);

        assertTrue(outContent.toString().contains("✅ OTP verified for user: Rahma"));
    }

    @Test
    public void testValidateOtp_Failure() {
        authentication.sendOtp("Rahma");

        
        authentication.validateOtp("Rahma", "123456");

        assertTrue(outContent.toString().contains("❌ Invalid OTP for user: Rahma"));
    }

    @Test
    public void testLogoutUser() {
        authentication.storeSessionData("Rahma", "token123");

        
        authentication.logoutUser("Rahma");

        assertTrue(outContent.toString().contains("👋 User logged out: Rahma"));
    }

    @Test
    public void testChangePassword_Success() {
        authentication.userCredentials.put("Rahma", "password123");

        // Change password
        authentication.changePassword("Rahma", "password123", "newPassword123");

        assertTrue(outContent.toString().contains("🔄 Password changed successfully."));
    }

    @Test
    public void testChangePassword_Failure() {
        authentication.userCredentials.put("Rahma", "password123");

       
        authentication.changePassword("Rahma", "wrongPassword", "newPassword123");

        assertTrue(outContent.toString().contains("❌ Incorrect old password."));
    }

    @Test
    public void testResetUserPassword() {
        authentication.resetUserPassword("Rahma", "newPassword123");

        assertTrue(outContent.toString().contains("🔑 Password reset for: Rahma"));
    }

    @Test
    public void testEnableTwoFactorAuthentication() {
        authentication.enableTwoFactorAuthentication("Rahma");

        assertTrue(outContent.toString().contains("🔐 Two-factor authentication enabled for: Rahma"));
    }

    @Test
    public void testAuthenticateViaToken_Success() {
        authentication.storeSessionData("Rahma", "validToken");

        authentication.authenticateViaToken("validToken");

        assertTrue(outContent.toString().contains("🔓 User authenticated via token."));
    }

    @Test
    public void testAuthenticateViaToken_Failure() {
        authentication.authenticateViaToken("invalidToken");

        assertTrue(outContent.toString().contains("❌ Invalid or expired token."));
    }
    
    @Test
    public void testUpdateSecurityQuestion() {
        authentication.updateSecurityQuestion("Rahma", "What is your pet's name?", "Fluffy");

        assertTrue(outContent.toString().contains("🔐 Security question updated for Rahma: What is your pet's name?"));
    }


    @Test
    public void testCheckLoginAttempts() {
        authentication.loginAttempts.put("Rahma", 3);

        authentication.checkLoginAttempts("Rahma");

        assertTrue(outContent.toString().contains("🔁 Login attempts for Rahma: 3"));
    }

    @Test
    public void testVerifyUserEmail() {
        authentication.verifyUserEmail("Rahma", "123456");

        assertTrue(outContent.toString().contains("📧 Verification email sent to Rahma. Please confirm with code: 123456"));
    }

    @Test
    public void testLogAuthenticationHistory() {
        authentication.logAuthenticationHistory("Rahma", "Login failed");

        assertTrue(outContent.toString().contains("📝 Log:"));
    }
}
