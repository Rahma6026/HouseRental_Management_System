

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.List;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ComplaintTest {
    private static Complaint complaint1;
    private static Complaint complaint2;
    private static Complaint complaint3;

    @BeforeClass
    public static void setUp() {
        System.out.println("Setting up complaints...\n");
        complaint1 = new Complaint("Nisha", "house1089", "Water Leakage", "Pipe burst in the kitchen");
        complaint2 = new Complaint("Arzu", "house1039", "", "Pipe burst in the kitchen");
        complaint3 = new Complaint("John", "house1090", "Electrical Issue", "Power fluctuation issues");
    }

    @Test
    public void test01_GenerateComplaintId() {
        String id = complaint1.getComplaintId();
        assertNotNull(id);
        assertEquals(true, id.startsWith("CMP-"));
        assertEquals(12, id.length());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test02_EmptyTitleThrowsException() {
        complaint2.emptyField();
    }

    @Test
    public void test03_ViewComplaintDetails() {
        assertEquals("Open", complaint1.getStatus());
    }

    @Test
    public void test04_FileComplaint() {
        complaint1.fileComplaint();
        assertNotNull(complaint1.getComplaintId());
        assertEquals(true, complaint1.getComplaintId().startsWith("CMP-"));
    }

    @Test
    public void test05_TagComplaintCategory() {
        complaint1.tagComplaintCategory("Plumbing");
        assertEquals("Plumbing", complaint1.getCategory());
    }

    @Test
    public void test06_RetagComplaintCategory() {
        complaint1.tagComplaintCategory("Water");
        assertEquals("Water", complaint1.getCategory());
    }

    @Test
    public void test07_AssignComplaintToAdmin() {
        complaint1.assignComplaintToAdmin();
        assertEquals("Admin123", complaint1.getAssignedAdminId());
    }

    @Test
    public void test08_UpdateComplaintStatusToInProgress() {
        complaint1.updateComplaintStatus("In Progress");
        assertEquals("In Progress", complaint1.getStatus());
    }

    @Test
    public void test09_ResolveComplaint() {
        complaint1.resolveComplaint();
        assertEquals("Resolved", complaint1.getStatus());
    }


    @Test
    public void test10_ComplaintHistoryTracking() {
        List<String> history = complaint1.getComplaintHistory();
        assertNotNull(history);
        assertEquals(true, history.size() >= 2);
    }

    @Test
    public void test11_VerifyComplaintTitle() {
        assertEquals("Water Leakage", complaint1.getTitle());
    }


    @Test
    public void test12_DownloadComplaintReport() {
        complaint1.downloadComplaintReport();
        assertEquals(true, complaint1.downloadComplaintReport());
    }

    @Test
    public void test13_UpdateStatusToNull() {
            complaint3.updateComplaintStatus(null);
            assertEquals(null, complaint3.getStatus());
       
    }

    @Test
    public void test14_TagCategoryWithEmptyString() {
        complaint3.tagComplaintCategory("");
        assertEquals("", complaint3.getCategory());
    }

  

    @Test
    public void test15_FileComplaintWithEmptyDescription() {
        Complaint complaint = new Complaint("Zara", "house2000", "Garbage", "");
        complaint.fileComplaint();
        assertEquals("", complaint.getDescription());  
    }

    @Test
    public void test16_AssignAdminWithoutFiling() {
        complaint2.assignComplaintToAdmin();
        assertEquals("Admin123", complaint2.getAssignedAdminId());  // Even though not filed, still assigns
    }

    @Test
    public void test17_UpdateStatusInvalidValue() {
        complaint3.updateComplaintStatus("Helloo");
        assertEquals("InvalidStatus", complaint3.getStatus()); // Accepts any string?
    }


    @Test
    public void test18_GetComplaintHistoryInitiallyEmpty() {
        List<String> history = complaint1.getComplaintHistory();
        assertNotNull(history);
        assertEquals(3, history.size());
      
    }
}