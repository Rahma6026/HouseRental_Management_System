
import java.io.*;
import java.text.SimpleDateFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class Utility {

 
    public String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
          return sdf.format(date);
    }
    public String formatCurrency(double amount) {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
          return currencyFormat.format(amount);
    }


    public boolean validateEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

   
    public boolean validatePhoneNumber(String phoneNumber) {
        String phoneRegex = "^\\+?[0-9]{10,15}$";
        return phoneNumber.matches(phoneRegex);
    }

 
    public String generateUniqueId() {
        return UUID.randomUUID().toString();
    }

 
   public String encryptData(String data, String key) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedData = cipher.doFinal(data.getBytes());
            return Base64.getEncoder().encodeToString(encryptedData);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

   
    public String decryptData(String encryptedData, String key) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedData = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
            return new String(decryptedData);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

  
    public double calculateTax(double amount) {
        final double TAX_RATE = 0.05;
        return amount * TAX_RATE;
    }

    public String convertToJSON(Map<String, String> map) {
        StringBuilder json = new StringBuilder("{");
        int count = 0;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            json.append("\"").append(entry.getKey()).append("\":");
            json.append("\"").append(entry.getValue()).append("\"");
            count++;
            if (count < map.size()) {
                json.append(",");
            }
        }
        json.append("}");
        return json.toString();
    }

 
    public Map<String, String> convertFromJSON(String jsonString) {
        Map<String, String> map = new HashMap<>();
        jsonString = jsonString.trim();
        if (jsonString.startsWith("{") && jsonString.endsWith("}")) {
            jsonString = jsonString.substring(1, jsonString.length() - 1); // remove {}
            String[] pairs = jsonString.split(",");
            for (String pair : pairs) {
                String[] keyValue = pair.split(":", 2);
                if (keyValue.length == 2) {
                    String key = keyValue[0].trim().replaceAll("^\"|\"$", "");
                    String value = keyValue[1].trim().replaceAll("^\"|\"$", "");
                    map.put(key, value);
                }
            }
        }
        return map;
    }


    public void generateQRCode(String text) {
        // Replace this with actual QR code library call if needed
        System.out.println("QR Code generated for: " + text);
    }

    // 12. Read from File
    public String readFromFile(String filePath) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }

 
    public void writeToFile(String filePath, String content) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            bw.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void logError(String errorMessage) {
        try (FileWriter fw = new FileWriter("error_log.txt", true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(new Date() + " - ERROR: " + errorMessage + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

  
    public void backupDatabase(String databasePath, String backupPath) {
        try {
            Files.copy(Paths.get(databasePath), Paths.get(backupPath), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Database backed up to: " + backupPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
