
public class HouseRentalManagementSystem {
    public static void main(String[] args) {
        System.out.println("===== House Rental Management System Started =====");

        // Admin setup
        Admin admin = new Admin("Rahma Mahbub", "rahmamahbub@gmail.com");
        System.out.println("\n-- Admin Operations --");
        admin.approveOwnerRegistration("OWNER001");
        admin.approveTenantRegistration("TENANT001");
        admin.manageUsers();
        admin.viewSystemReports();

        // Tenant setup
        Tenant tenant = new Tenant("TENANT001", "sahara Omi", "omi@example.com", "password123");
        System.out.println("\n-- Tenant Operations --");
        tenant.viewAvailableProperties();
        tenant.sendMaintenanceRequest("Request001", "Leaky faucet in bathroom");
        tenant.submitFeedback("Great service and well-maintained property.");

        // Owner setup
        Owner owner = new Owner("OWNER001", "Tammana");
        System.out.println("\n-- Owner Operations --");
        owner.listProperty("House001");
        owner.viewProperties();
        owner.viewFeedback();


        System.out.println("\n-- Rental Simulation --");
        System.out.println("Tenant " + tenant.getName() + " is renting property House001.");
        System.out.println("Rental request approved by owner " + owner.getName() + ".");

        System.out.println("\n===== House Rental Management System Ended =====");
    }
}
