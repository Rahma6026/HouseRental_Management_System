

import java.util.*;

public class House {
    private String houseId;
    private String address;
    private double price;
    private boolean isAvailable;
    private String ownerName;
    private List<String> houseImages;

    public House(String address, double price, String ownerName) {
        this.houseId = generateHouseId();
        this.address = address;
        this.price = price;
        this.isAvailable = true;
        this.ownerName = ownerName;
        this.houseImages = new ArrayList<>();
    }

    public void addHouse() {
        System.out.println("House added: " + houseId + " | " + address);
    }

    public void removeHouse() {
        System.out.println("House removed: " + houseId);
    }

    public void updateHouseDetails(String newAddress, double newPrice) {
        this.address = newAddress;
        this.price = newPrice;
        System.out.println("House details updated for: " + houseId);
    }

    public static void listHouses(List<House> houses) {
        System.out.println("Listing all houses:");
        for (House h : houses) {
            System.out.println(h.houseId + " | " + h.address + " | $" + h.price + " | Available: " + h.isAvailable);
        }
    }

    public static void searchHouseByLocation(List<House> houses, String location) {
        System.out.println("Searching for houses in: " + location);
        for (House h : houses) {
            if (h.address.toLowerCase().contains(location.toLowerCase())) {
                System.out.println("Found: " + h.houseId + " | " + h.address);
            }
        }
    }

    public static void searchHouseByPrice(List<House> houses, double minPrice, double maxPrice) {
        System.out.println("Searching for houses in price range $" + minPrice + " - $" + maxPrice);
        for (House h : houses) {
            if (h.price >= minPrice && h.price <= maxPrice) {
                System.out.println("Found: " + h.houseId + " | $" + h.price);
            }
        }
    }

    public void markHouseAsRented() {
        this.isAvailable = false;
        System.out.println("House " + houseId + " marked as rented.");
    }

    public void markHouseAsAvailable() {
        this.isAvailable = true;
        System.out.println("House " + houseId + " marked as available.");
    }

    public void viewHouseDetails() {
        System.out.println("House ID: " + houseId);
        System.out.println("Address: " + address);
        System.out.println("Price: $" + price);
        System.out.println("Available: " + isAvailable);
        System.out.println("Owner: " + ownerName);
        System.out.println("Images: " + houseImages.size() + " image(s) uploaded.");
    }

    public void assignOwner(String newOwnerName) {
        this.ownerName = newOwnerName;
        System.out.println("Owner assigned to house " + houseId + ": " + ownerName);
    }

    public void calculateRent(int months) {
        double total = price * months;
        System.out.println("Total rent for " + months + " month(s): $" + total);
    }

    public void checkAvailability() {
        System.out.println("House " + houseId + " is " + (isAvailable ? "Available" : "Not Available"));
    }

    public void validateHouseData() {
        if (address == null || address.isEmpty() || price <= 0) {
            System.out.println("Invalid house data for: " + houseId);
        } else {
            System.out.println("House data is valid for: " + houseId);
        }
    }

    public void uploadHouseImages(String imageName) {
        houseImages.add(imageName);
        System.out.println("Image uploaded for house " + houseId + ": " + imageName);
    }

    private String generateHouseId() {
        return "H-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    // ✅ This method was missing or overwritten in your version
    public boolean isAvailable() {
        return isAvailable;
    }

    // Getters
    public String getHouseId() {
        return houseId;
    }

    public String getAddress() {
        return address;
    }

    public double getPrice() {
        return price;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public List<String> getHouseImages() {
        return houseImages;
    }
}
