

import java.util.List;

class UserProfile {
    private String userId;
    private String userName;
    private String profilePicture;
    private String email;
    private String phone;
    private String securitySettings;
    private List<String> transactionHistory;
    private List<String> notifications;
    private List<String> properties;
    private List<String> feedback;

    public UserProfile(String userId, String userName, String email, String phone) {
        this.userId = userId;
        this.userName = userName;
        this.email = email;
        this.phone = phone;
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    
    public void createProfile() {
        System.out.println("Profile created for: " + this.userName);
    }

    
    public void updateProfile(String userName, String email, String phone) {
        this.userName = userName;
        this.email = email;
        this.phone = phone;
        System.out.println("Profile updated for: " + this.userName);
    }

  
    public void viewProfile() {
        System.out.println("User Profile Details:");
        System.out.println("User ID: " + this.userId);
        System.out.println("Name: " + this.userName);
        System.out.println("Email: " + this.email);
        System.out.println("Phone: " + this.phone);
        System.out.println("Profile Picture: " + this.profilePicture);
    }

   
    public void deleteProfile() {
        System.out.println("Profile deleted for: " + this.userName);
    }

   
    public void uploadProfilePicture(String picture) {
        this.profilePicture = picture;
        System.out.println("Profile picture uploaded for: " + this.userName);
    }

    
    public void changeProfileSettings(String setting, String value) {
        System.out.println("Profile setting " + setting + " changed to: " + value);
    }

    
    public void viewTransactionHistory() {
        if (transactionHistory != null && !transactionHistory.isEmpty()) {
            System.out.println("Transaction History for: " + this.userName);
            for (String transaction : transactionHistory) {
                System.out.println(transaction);
            }
        } else {
            System.out.println("No transaction history available.");
        }
    }

   
    public void updateSecuritySettings(String setting, String value) {
        this.securitySettings = setting + ": " + value;
        System.out.println("Security setting updated to: " + this.securitySettings);
    }

    
    public void sendProfileInvite(String inviteeEmail) {
        System.out.println("Profile invite sent to: " + inviteeEmail);
    }

    
    public void viewProfileStatistics() {
        System.out.println("Profile Statistics for: " + this.userName);
        System.out.println("Number of Properties: " + (properties != null ? properties.size() : 1));
        System.out.println("Number of Transactions: " + (transactionHistory != null ? transactionHistory.size() : 0));
        System.out.println("Number of Feedbacks: " + (feedback != null ? feedback.size() : 0));
    }

    
    public void blockUser(String userToBlock) {
        System.out.println("User " + userToBlock + " has been blocked.");
    }

    
    public void viewUserNotifications() {
        if (notifications != null && !notifications.isEmpty()) {
            System.out.println("Notifications for: " + this.userName);
            for (String notification : notifications) {
                System.out.println(notification);
            }
        } else {
            System.out.println("No notifications available.");
        }
    }

    
    public void listUserProperties() {
        if (properties != null && !properties.isEmpty()) {
            System.out.println("Properties owned by: " + this.userName);
            for (String property : properties) {
                System.out.println(property);
            }
        } else {
            System.out.println("No properties listed.");
        }
    }

    
    public void viewUserFeedback() {
        if (feedback != null && !feedback.isEmpty()) {
            System.out.println("Feedback for: " + this.userName);
            for (String fb : feedback) {
                System.out.println(fb);
            }
        } else {
            System.out.println("No feedback available.");
        }
    }

    public static void main(String[] args) {
        UserProfile userProfile = new UserProfile("user123", "Rahma Adithi", "rahma1234@gmail.com", "01331034751");
        userProfile.createProfile();
        userProfile.updateProfile("Rahma Mahbub", "rahmamahbub@gmail.com", "01331034751");
        userProfile.viewProfile();
        userProfile.uploadProfilePicture("profilePic.jpg");
        userProfile.viewProfileStatistics();
        userProfile.viewTransactionHistory();
    }
}
