

import java.util.*;

public class Payment {
    private String paymentId;
    private String tenantId;
    private String houseId;
    private double amount;
    private Date paymentDate;
    private String status;
    private List<String> paymentHistory;
    private Map<String, String> paymentMethods;

    public Payment(String tenantId, String houseId, double amount) {
        this.paymentId = generatePaymentId();
        this.tenantId = tenantId;
        this.houseId = houseId;
        this.amount = amount;
        this.paymentDate = new Date();
        this.status = "Pending";
        this.paymentHistory = new ArrayList<>();
        this.paymentMethods = new HashMap<>();
    }

    private String generatePaymentId() {
        return "PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public void processPayment() {
        this.status = "Completed";
        this.paymentDate = new Date();
        paymentHistory.add(paymentId + " | " + amount + " | " + paymentDate + " | " + status);
        System.out.println("Payment processed successfully.");
    }

    public void viewPaymentHistory() {
        System.out.println("Payment History:");
        for (String history : paymentHistory) {
            System.out.println(history);
        }
    }

    public void refundPayment() {
        if (status.equals("Completed")) {
            status = "Refunded";
            System.out.println("Payment refunded.");
        } else {
            System.out.println("Refund not allowed. Payment is not completed.");
        }
    }

    public void generateInvoice() {
        System.out.println("Generating invoice for Payment ID: " + paymentId);
        System.out.println("Tenant ID: " + tenantId);
        System.out.println("House ID: " + houseId);
        System.out.println("Amount: $" + amount);
        System.out.println("Date: " + paymentDate);
        System.out.println("Status: " + status);
    }

    public void sendPaymentReminder() {
        System.out.println("Reminder: Payment of $" + amount + " is pending for Tenant ID: " + tenantId);
    }

    public void confirmPaymentReceipt() {
        if (status.equals("Completed")) {
            System.out.println("Payment receipt confirmed for Payment ID: " + paymentId);
        } else {
            System.out.println("No completed payment to confirm.");
        }
    }

    public void trackPaymentStatus() {
        System.out.println("Payment Status for Payment ID " + paymentId + ": " + status);
    }

    public void viewPendingPayments() {
        if (status.equals("Pending")) {
            System.out.println("Pending payment for Tenant ID: " + tenantId + " | Amount: $" + amount);
        } else {
            System.out.println("No pending payments.");
        }
    }

    public void calculateLateFees(int daysLate) {
        if (daysLate > 0) {
            double lateFee = daysLate * 5.0; // $5 per day
            System.out.println("Late fee for " + daysLate + " days: $" + lateFee);
        } else {
            System.out.println("No late fees.");
        }
    }

    public void updatePaymentStatus(String newStatus) {
        this.status = newStatus;
        System.out.println("Payment status updated to: " + status);
    }

    public void exportPaymentsToCSV() {
        System.out.println("Exporting payments to CSV...");
        for (String record : paymentHistory) {
            System.out.println(record.replace(" | ", ","));
        }
    }

    public void integrateWithBank(String bankName) {
        System.out.println("Integrating payment system with bank: " + bankName);
      
        System.out.println("Integration successful with " + bankName);
    }

    public void setupAutoPayment(String paymentMethodId) {
        if (paymentMethods.containsKey(paymentMethodId)) {
            System.out.println("Auto-payment enabled using: " + paymentMethods.get(paymentMethodId));
        } else {
            System.out.println("Payment method not found.");
        }
    }

    public void addPaymentMethod(String methodId, String methodDetails) {
        paymentMethods.put(methodId, methodDetails);
        System.out.println("Payment method added: " + methodId);
    }

    public void removePaymentMethod(String methodId) {
        if (paymentMethods.containsKey(methodId)) {
            paymentMethods.remove(methodId);
            System.out.println("Payment method removed: " + methodId);
        } else {
            System.out.println("Payment method ID not found.");
        }
    }

   
    public String getPaymentId() {
        return paymentId;
    }

    public String getStatus() {
        return status;
    }

    public double getAmount() {
        return amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public List<String> getPaymentHistory() {
        return paymentHistory;
    }
}
