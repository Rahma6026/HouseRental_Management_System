
import java.util.*;

public class Notification {
    private static int notificationCounter = 0;
    private String notificationId;
    private String userId;
    private String message;
    private Date timestamp;
    private boolean isRead;
    private boolean isArchived;
    private String type; // EMAIL, SMS, PUSH
    private static List<Notification> notificationLog = new ArrayList<>();

    public Notification(String userId, String message, String type) {
        this.notificationId = "NTF-" + (++notificationCounter);
        this.userId = userId;
        this.message = message;
        this.type = type;
        this.timestamp = new Date();
        this.isRead = false;
        this.isArchived = false;
        notificationLog.add(this);
    }

    public void sendEmailNotification() {
        if (type.equalsIgnoreCase("EMAIL")) {
            System.out.println("📧 Email sent to User ID: " + userId + " | Message: " + message);
        }
    }

    public void sendSMSNotification() {
        if (type.equalsIgnoreCase("SMS")) {
            System.out.println("📱 SMS sent to User ID: " + userId + " | Message: " + message);
        }
    }

    public void sendPushNotification() {
        if (type.equalsIgnoreCase("PUSH")) {
            System.out.println("🔔 Push Notification sent to User ID: " + userId + " | Message: " + message);
        }
    }

    public void createNotification(String newMessage, String newType) {
        Notification newNotification = new Notification(this.userId, newMessage, newType);
        System.out.println("Notification created: " + newNotification.notificationId);
    }

    public void viewAllNotifications() {
        System.out.println("🔔 Viewing all notifications for user: " + userId);
        for (Notification n : notificationLog) {
            if (n.userId.equals(this.userId)) {
                System.out.println(n.notificationId + " | " + n.message + " | " + n.type + " | " + (n.isRead ? "Read" : "Unread"));
            }
        }
    }

    public void deleteNotification(String id) {
        notificationLog.removeIf(n -> n.notificationId.equals(id));
        System.out.println("Notification " + id + " deleted.");
    }

    public void updateNotificationSettings(String newType) {
        this.type = newType;
        System.out.println("Notification type updated to: " + newType);
    }

    public void markAsRead() {
        this.isRead = true;
        System.out.println("Notification marked as read.");
    }

    public void markAsUnread() {
        this.isRead = false;
        System.out.println("Notification marked as unread.");
    }

    public void scheduleNotification(Date scheduledTime) {
        System.out.println("Notification scheduled at: " + scheduledTime + " for User ID: " + userId);
     
    }

    public void resendNotification() {
        System.out.println("Resending Notification to User ID: " + userId + " | Message: " + message);
    }

    public List<Notification> getNotificationHistory() {
        System.out.println("Notification History for User ID: " + userId);
        for (Notification n : notificationLog) {
            if (n.userId.equals(this.userId)) {
                System.out.println("- " + n.notificationId + " | " + n.message + " | " + n.timestamp);
            }
        }
		return null;
    }

    public int getUnreadCount() {
        long count = notificationLog.stream().filter(n -> n.userId.equals(this.userId) && !n.isRead).count();
        System.out.println("Unread notifications: " + count);
		return 0;
    }

    public void archiveNotification() {
        this.isArchived = true;
        System.out.println("Notification archived.");
    }

    public void notifyOnPaymentDue(double amount, Date dueDate) {
        String dueMessage = "⚠️ Payment of $" + amount + " is due on " + dueDate;
        Notification paymentNotification = new Notification(this.userId, dueMessage, "EMAIL");
        paymentNotification.sendEmailNotification();
    }

    
    public String getNotificationId() {
        return notificationId;
    }

    public boolean isRead() {
        return isRead;
    }

    public boolean isArchived() {
        return isArchived;
    }

    public String getType() {
        return type;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public static List<Notification> getNotificationLog() {
        return notificationLog;
    }

	public List<Notification> getMessage1() {
		return null;
	}
}
