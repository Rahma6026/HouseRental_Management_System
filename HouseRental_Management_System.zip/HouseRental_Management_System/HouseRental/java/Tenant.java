

import java.util.*;

public class Tenant {
    private String tenantId;
    private String name;
    private String email;
    private String phoneNumber;
    private List<String> rentHistory;
    private List<String> issuesRaised;

    private House rentedHouse;
    private boolean hasActiveLease;

    public Tenant(String tenantId, String name, String email, String password) {
        this.tenantId = tenantId;
        this.name = name;
        this.email = email;
        this.phoneNumber = "";
        this.rentHistory = new ArrayList<>();
        this.issuesRaised = new ArrayList<>();
        this.hasActiveLease = false;
    }

    // View available properties
    public void viewAvailableProperties() {
        System.out.println("Displaying available properties for tenant: " + name);
    }

    // Send maintenance request
    public void sendMaintenanceRequest(String requestId, String description) {
        System.out.println("Maintenance Request Sent [" + requestId + "]: " + description);
        logIssue(description);
    }

    // Submit feedback
    public void submitFeedback(String feedback) {
        System.out.println("Feedback from " + name + ": " + feedback);
    }

    // Pay rent
    public void payRent(double amount) {
        String record = "Paid rent: $" + amount + " on " + new Date();
        rentHistory.add(record);
        System.out.println(record);
    }

    // View rent history
    public void viewRentHistory() {
        System.out.println("Rent History for " + name + ":");
        for (String record : rentHistory) {
            System.out.println(record);
        }
    }

    // End lease
    public void endLease() {
        if (hasActiveLease) {
            hasActiveLease = false;
            rentedHouse = null;
            System.out.println("Lease ended for tenant: " + name);
        } else {
            System.out.println("No active lease to end.");
        }
    }

    // Request lease extension
    public void requestLeaseExtension() {
        if (hasActiveLease) {
            System.out.println("Lease extension requested for tenant: " + name);
        } else {
            System.out.println("Cannot request extension without an active lease.");
        }
    }

    // Update contact info
    public void updatePhoneNumber(String newPhone) {
        this.phoneNumber = newPhone;
        System.out.println("Phone number updated to: " + newPhone);
    }

    // Change password
    public void changePassword(String newPassword) {
        System.out.println("Password successfully updated.");
    }

    // View raised issues
    public void viewIssues() {
        System.out.println("Issues raised by " + name + ":");
        for (String issue : issuesRaised) {
            System.out.println("- " + issue);
        }
    }

    // Report neighbor issue
    public void reportNeighborIssue(String complaint) {
        logIssue("Neighbor issue: " + complaint);
        System.out.println("Neighbor issue reported: " + complaint);
    }

    // View tenant profile
    public void viewProfile() {
        System.out.println("Tenant Profile:");
        System.out.println("ID: " + tenantId);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phoneNumber);
        System.out.println("Active Lease: " + hasActiveLease);
    }

    // Logout
    public void logout() {
        System.out.println(name + " has logged out.");
    }

    // Log issue (private)
    private void logIssue(String issueDescription) {
        if (!issuesRaised.contains(issueDescription)) {
            issuesRaised.add(issueDescription);
        }
    }

    // Set rented house (simulate lease start)
    public void setRentedHouse(House house) {
        this.rentedHouse = house;
        this.hasActiveLease = true;
        System.out.println("Lease started for house: " + house);
    }

    // Getters
    public String getTenantId() {
        return tenantId;
    }

    public String getName() {
        return name;
    }

    public House getRentedHouse() {
        return rentedHouse;
    }

    public boolean hasActiveLease() {
        return hasActiveLease;
    }

    public List<String> getIssuesRaised() {
        return issuesRaised;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}
