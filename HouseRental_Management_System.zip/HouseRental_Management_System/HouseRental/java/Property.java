

import java.util.ArrayList;
import java.util.List;

class Property {
    private String propertyId;
    private String propertyType;
    private String propertyLocation;
    private double price;
    private boolean isAvailable;
    private List<String> propertyImages;

    public Property(String propertyType, String propertyLocation, double price) {
        this.propertyType = propertyType;
        this.propertyLocation = propertyLocation;
        this.price = price;
        this.isAvailable = true;
        this.propertyImages = new ArrayList<>();
        this.propertyId = generatePropertyId();
    }

   
    public void addProperty() {
        System.out.println("Property added: " + this.propertyId);
    }

  
    public void removeProperty() {
        System.out.println("Property removed: " + this.propertyId);
    }

   
    public void updatePropertyDetails(String propertyType, String propertyLocation, double price) {
        this.propertyType = propertyType;
        this.propertyLocation = propertyLocation;
        this.price = price;
        System.out.println("Property details updated: " + this.propertyId);
    }

 
    public void listAllProperties(List<Property> properties) {
        for (Property property : properties) {
            System.out.println("Property ID: " + property.propertyId);
            System.out.println("Property Type: " + property.propertyType);
            System.out.println("Property Location: " + property.propertyLocation);
            System.out.println("Price: " + property.price);
        }
    }

    
    public void searchPropertyByType(String type) {
        if (this.propertyType.equalsIgnoreCase(type)) {
            System.out.println("Property found: " + this.propertyId);
        }
    }

   
    public void filterPropertiesByPrice(double minPrice, double maxPrice) {
        if (this.price >= minPrice && this.price <= maxPrice) {
            System.out.println("Property within price range: " + this.propertyId);
        }
    }

    
    public void viewPropertyDetails() {
        System.out.println("Property ID: " + this.propertyId);
        System.out.println("Type: " + this.propertyType);
        System.out.println("Location: " + this.propertyLocation);
        System.out.println("Price: " + this.price);
        System.out.println("Availability: " + (this.isAvailable ? "Available" : "Not Available"));
    }

  
    public void assignPropertyToOwner(String ownerId) {
        System.out.println("Property assigned to Owner: " + ownerId);
    }

    public String generatePropertyId() {
        return "PROP-" + System.currentTimeMillis();
    }

    public void calculatePropertyValue() {
        double value = this.price * 1.2; 
        System.out.println("Estimated property value: " + value);
    }

    public void checkPropertyAvailability() {
        if (this.isAvailable) {
            System.out.println("Property is available.");
        } else {
            System.out.println("Property is not available.");
        }
    }

    // Validate property data (basic validation example)
    public void validatePropertyData() {
        if (this.propertyLocation == null || this.propertyLocation.isEmpty()) {
            System.out.println("Invalid property location.");
        }
        if (this.price <= 0) {
            System.out.println("Invalid property price.");
        }
        if (this.propertyType == null || this.propertyType.isEmpty()) {
            System.out.println("Invalid property type.");
        }
    }


    public void uploadPropertyImages(List<String> images) {
        this.propertyImages.addAll(images);
        System.out.println("Images uploaded for Property ID: " + this.propertyId);
    }

   
    public void getPropertyAnalytics() {
        System.out.println("Analytics for Property ID: " + this.propertyId);
        System.out.println("Total images uploaded: " + this.propertyImages.size());
    }

    public static void main(String[] args) {
      
        Property property1 = new Property("Apartment", "Downtown", 1500);
        property1.addProperty();
        property1.updatePropertyDetails("House", "Uptown", 2000);
        property1.viewPropertyDetails();
        
        List<Property> properties = new ArrayList<>();
        properties.add(property1);

        property1.listAllProperties(properties);
    }
}
