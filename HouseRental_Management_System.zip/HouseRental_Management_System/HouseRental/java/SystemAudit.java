

import java.util.HashMap;
import java.util.Map;

class SystemAudit {
    private Map<String, String> systemLogs;  
    private Map<String, String> userActions; 
    private Map<String, String> systemChanges; 
    public SystemAudit() {
        systemLogs = new HashMap<>();
        userActions = new HashMap<>();
        systemChanges = new HashMap<>();
    }

    public void logUserAction(String actionId, String actionDescription) {
        userActions.put(actionId, actionDescription);
        System.out.println("User action logged: " + actionDescription);
    }

    // View all system logs
    public void viewSystemLogs() {
        System.out.println("Viewing system logs:");
        systemLogs.forEach((key, value) -> System.out.println("Log ID: " + key + " - Log: " + value));
    }

    public void generateAuditReport(String reportId) {
        System.out.println("Generating audit report with ID: " + reportId);
   
    }

    // Track system changes
    public void trackSystemChanges(String changeId, String changeDescription) {
        systemChanges.put(changeId, changeDescription);
        System.out.println("System change tracked: " + changeDescription);
    }

    
    public void checkSecurityBreach() {
        System.out.println("Checking for security breaches...");
       
    }

    
    public void reviewUserActivity(String userId) {
        System.out.println("Reviewing activity for user ID: " + userId);
        userActions.forEach((key, value) -> {
            if (key.contains(userId)) {
                System.out.println("User Action ID: " + key + " - Action: " + value);
            }
        });
    }

    public void monitorSystemHealth() {
        System.out.println("Monitoring system health...");
      
    }

    // Handle unauthorized access attempts
    public void handleUnauthorizedAccess(String accessAttemptId, String description) {
        System.out.println("Unauthorized access attempt detected: " + description);
        systemLogs.put(accessAttemptId, "Unauthorized access detected: " + description);
    }

    // Analyze the performance of the system
    public void analyzeSystemPerformance() {
        System.out.println("Analyzing system performance...");
        
    }

    // Perform a database backup
    public void performDatabaseBackup() {
        System.out.println("Performing database backup...");
       
    }

    // Track admin actions in the system
    public void trackAdminActions(String adminId, String actionDescription) {
        System.out.println("Tracking admin action: " + actionDescription);
        systemLogs.put(adminId, actionDescription);
    }

    public void notifyAdminOnCriticalLogs() {
        System.out.println("Notifying admin about critical system logs...");
        
    }

    public void exportAuditData() {
        System.out.println("Exporting audit data...");
       
    }

    public static void main(String[] args) {
      
        SystemAudit audit = new SystemAudit();

      
        audit.logUserAction("UA1001", "User logged in");
        audit.logUserAction("UA1002", "User updated profile");

    
        audit.viewSystemLogs();

        audit.generateAuditReport("AR1001");

        audit.trackSystemChanges("SC1001", "Updated server settings");

        audit.checkSecurityBreach();

        audit.reviewUserActivity("1001");

      
        audit.monitorSystemHealth();

        audit.handleUnauthorizedAccess("UA1003", "Failed login attempt from unknown IP");

       
        audit.analyzeSystemPerformance();

        audit.performDatabaseBackup();

        audit.trackAdminActions("ADMIN001", "Admin updated system settings");

        audit.notifyAdminOnCriticalLogs();

        audit.exportAuditData();
    }
}
