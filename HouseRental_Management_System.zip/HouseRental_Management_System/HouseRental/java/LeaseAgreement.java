

import java.util.*;

public class LeaseAgreement {
    private String agreementId;
    private String houseId;
    private String tenantId;
    private String ownerId;
    private Date startDate;
    private Date endDate;
    private boolean isSigned;
    private boolean isTerminated;
    private boolean isArchived;
    private String agreementContent;

    public LeaseAgreement(String houseId, String tenantId, String ownerId) {
        this.agreementId = generateAgreementId();
        this.houseId = houseId;
        this.tenantId = tenantId;
        this.ownerId = ownerId;
        this.isSigned = false;
        this.isTerminated = false;
        this.isArchived = false;
        this.agreementContent = "";
    }

    private String generateAgreementId() {
        return "AGMT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public void createAgreement(String content) {
        this.agreementContent = content;
        System.out.println("Lease agreement created.");
    }

    public void signAgreement() {
        if (!isTerminated && !isArchived) {
            this.isSigned = true;
            System.out.println("Agreement signed by all parties.");
        } else {
            System.out.println("Cannot sign. Agreement is either terminated or archived.");
        }
    }

    public void viewAgreement() {
        System.out.println("Viewing Lease Agreement:");
        System.out.println("Agreement ID: " + agreementId);
        System.out.println("House ID: " + houseId);
        System.out.println("Tenant ID: " + tenantId);
        System.out.println("Owner ID: " + ownerId);
        System.out.println("Start Date: " + startDate);
        System.out.println("End Date: " + endDate);
        System.out.println("Signed: " + isSigned);
        System.out.println("Terminated: " + isTerminated);
        System.out.println("Archived: " + isArchived);
        System.out.println("Content: " + agreementContent);
    }

    public void updateAgreement(String updatedContent) {
        if (!isTerminated && !isArchived) {
            this.agreementContent = updatedContent;
            System.out.println("Agreement content updated.");
        } else {
            System.out.println("Cannot update a terminated or archived agreement.");
        }
    }

    public void terminateAgreement() {
        if (!isTerminated) {
            isTerminated = true;
            System.out.println("Lease agreement terminated.");
        } else {
            System.out.println("Agreement already terminated.");
        }
    }

    public void renewAgreement(Date newEndDate) {
        if (!isTerminated && !isArchived) {
            this.endDate = newEndDate;
            System.out.println("Lease agreement renewed until: " + endDate);
        } else {
            System.out.println("Cannot renew. Agreement is either terminated or archived.");
        }
    }

    public void downloadAgreement() {
        System.out.println("Downloading agreement...");
        System.out.println("Agreement Content:\n" + agreementContent);
    }

    public void storeAgreement() {
        System.out.println("Lease agreement stored in system database.");
    }

    public boolean verifyAgreement() {
        if (isSigned && !isTerminated && !isArchived) {
            System.out.println("Agreement is valid.");
            return true;
        } else {
            System.out.println("Agreement is invalid.");
            return false;
        }
    }

    public void notifyParties() {
        System.out.println("Notification sent to tenant and owner regarding agreement status.");
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
        System.out.println("Agreement start date set to: " + startDate);
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
        System.out.println("Agreement end date set to: " + endDate);
    }

    public void checkAgreementValidity() {
        Date current = new Date();
        if (current.after(startDate) && current.before(endDate) && !isTerminated && isSigned) {
            System.out.println("Agreement is currently valid.");
        } else {
            System.out.println("Agreement is not currently valid.");
        }
    }

    public void archiveAgreement() {
        if (!isArchived) {
            this.isArchived = true;
            System.out.println("Lease agreement archived.");
        } else {
            System.out.println("Agreement is already archived.");
        }
    }

    public void getAgreementDetails() {
        System.out.println("Agreement Details:");
        System.out.println("Agreement ID: " + agreementId);
        System.out.println("Tenant ID: " + tenantId);
        System.out.println("Owner ID: " + ownerId);
        System.out.println("House ID: " + houseId);
        System.out.println("Valid From: " + startDate + " To: " + endDate);
        System.out.println("Status: " + (isSigned ? "Signed" : "Unsigned") +
                           ", " + (isTerminated ? "Terminated" : "Active") +
                           ", " + (isArchived ? "Archived" : "Not Archived"));
    }

    // Getters (optional if needed)
    public String getAgreementId() {
        return agreementId;
    }

    public boolean isSigned() {
        return isSigned;
    }

    public boolean isTerminated() {
        return isTerminated;
    }

    public boolean isArchived() {
        return isArchived;
    }

	public Object getEndDate() {
		return null;
	}
	
}
