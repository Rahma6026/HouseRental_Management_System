

import java.util.*;

public class Owner {
    private String ownerId;
    private String name;
    private String email;
    private String password;
    private String phoneNumber;
    private List<House> ownedHouses;
    private List<String> transactionHistory;
    private List<String> feedbackList;

    public Owner(String name, String email) {
        this.ownerId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.name = name;
        this.email = email;
        this.password = "defaultPass";
        this.phoneNumber = "";
        this.ownedHouses = new ArrayList<>();
        this.transactionHistory = new ArrayList<>();
        this.feedbackList = new ArrayList<>();
    }

    public void registerOwner() {
        System.out.println("Owner registered: " + name);
    }

    public void loginOwner(String email, String password) {
        if (this.email.equals(email) && this.password.equals(password)) {
            System.out.println("Owner logged in successfully: " + name);
        } else {
            System.out.println("Invalid credentials for owner: " + name);
        }
    }

    public void updateOwnerProfile(String newName, String newPhoneNumber) {
        this.name = newName;
        this.phoneNumber = newPhoneNumber;
        System.out.println("Owner profile updated: " + name);
    }

    public void deleteOwnerAccount() {
        System.out.println("Owner account deleted: " + name);
    }

    public void listOwnerHouses() {
        System.out.println("Listing owned houses for " + name + ":");
        for (House house : ownedHouses) {
            System.out.println(house.getHouseId() + " | " + house.getAddress());
        }
    }

    public void assignHouseToTenant(House house, String tenantName) {
        if (ownedHouses.contains(house)) {
            house.markHouseAsRented();
            transactionHistory.add("Assigned house " + house.getHouseId() + " to tenant: " + tenantName);
            System.out.println("House " + house.getHouseId() + " assigned to tenant: " + tenantName);
        } else {
            System.out.println("This house does not belong to owner: " + name);
        }
    }

    public void receiveRent(House house, double rentAmount) {
        transactionHistory.add("Received rent of $" + rentAmount + " for house: " + house.getHouseId());
        System.out.println("Received rent of $" + rentAmount + " for house " + house.getHouseId());
    }

    public void viewTransactionHistory() {
        System.out.println("Transaction history for " + name + ":");
        for (String transaction : transactionHistory) {
            System.out.println(transaction);
        }
    }

    public void changePassword(String newPassword) {
        this.password = newPassword;
        System.out.println("Password changed successfully for owner: " + name);
    }

    public void viewOwnerDetails() {
        System.out.println("Owner Details:");
        System.out.println("ID: " + ownerId);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Owned Houses: " + ownedHouses.size());
    }

    public void approveHouseListing(House house) {
        System.out.println("House listing approved for: " + house.getHouseId());
    }

    public void uploadOwnerDocuments(String documentName) {
        System.out.println("Document uploaded: " + documentName + " for owner: " + name);
    }

    public void verifyOwnership(House house) {
        if (ownedHouses.contains(house)) {
            System.out.println("Ownership verified for house: " + house.getHouseId());
        } else {
            System.out.println("House " + house.getHouseId() + " does not belong to owner: " + name);
        }
    }

    public void messageTenant(String tenantName, String message) {
        System.out.println("Message sent to tenant " + tenantName + ": " + message);
    }

    public void getRentalAnalytics() {
        double totalRent = 0;
        for (House house : ownedHouses) {
            if (!house.isAvailable()) {
                totalRent += house.getPrice();
            }
        }
        System.out.println("Total rent collected from rented houses: $" + totalRent);
    }

    public void addHouseToOwner(House house) {
        ownedHouses.add(house);
        System.out.println("House " + house.getHouseId() + " added to owner " + name);
    }

    public void listProperty(String propertyId) {
        System.out.println("Property listed with ID: " + propertyId + " by owner " + name);
    }

    public void viewFeedback() {
        System.out.println("Feedback for owner " + name + ":");
        if (feedbackList.isEmpty()) {
            System.out.println("No feedback available.");
        } else {
            for (String feedback : feedbackList) {
                System.out.println("- " + feedback);
            }
        }
    }

    public void viewProperties() {
        System.out.println("Properties owned by " + name + ":");
        for (House house : ownedHouses) {
            System.out.println(house.getHouseId() + " - " + house.getAddress());
        }
    }

    public void receiveFeedback(String feedback) {
        feedbackList.add(feedback);
    }

    // Getters
    public String getOwnerId() {
        return ownerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public List<House> getOwnedHouses() {
        return ownedHouses;
    }
}
