

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class RentalHistory {
    private String tenantId;
    private String houseId;
    private double rentAmount;
    private Date rentalStartDate;
    private Date rentalEndDate;
    private boolean rentPaid;
    private List<String> rentalRecords = new ArrayList<>();

    public RentalHistory(String tenantId, String houseId, double rentAmount, Date rentalStartDate, Date rentalEndDate) {
        this.tenantId = tenantId;
        this.houseId = houseId;
        this.rentAmount = rentAmount;
        this.rentalStartDate = rentalStartDate;
        this.rentalEndDate = rentalEndDate;
        this.rentPaid = false;
    }

    // Getters and Setters for rentalStartDate and rentalEndDate
    public Date getRentalStartDate() {
        return rentalStartDate;
    }

    public void setRentalStartDate(Date rentalStartDate) {
        this.rentalStartDate = rentalStartDate;
    }

    public Date getRentalEndDate() {
        return rentalEndDate;
    }

    public void setRentalEndDate(Date rentalEndDate) {
        this.rentalEndDate = rentalEndDate;
    }

    public void viewRentalHistory() {
        System.out.println("Rental History for Tenant: " + this.tenantId);
        for (String record : rentalRecords) {
            System.out.println(record);
        }
    }

    public void addRentalRecord(String houseId, double rentAmount, Date startDate, Date endDate) {
        rentalRecords.add("House: " + houseId + ", Rent: " + rentAmount + ", Start Date: " + startDate + ", End Date: " + endDate);
        System.out.println("Rental record added for House: " + houseId);
    }

    public void updateRentalRecord(String houseId, double rentAmount, Date startDate, Date endDate) {
        deleteRentalRecord(houseId);
        addRentalRecord(houseId, rentAmount, startDate, endDate);
        System.out.println("Rental record updated for House: " + houseId);
    }

    public void deleteRentalRecord(String houseId) {
        rentalRecords.removeIf(record -> record.contains(houseId));
        System.out.println("Rental record deleted for House: " + houseId);
    }

    public void filterRentalHistoryByDate(Date startDate, Date endDate) {
        System.out.println("Rental history filtered from " + startDate + " to " + endDate);
        // Add filtering logic here as needed
    }

    public void filterRentalHistoryByHouse(String houseId) {
        System.out.println("Rental history filtered for House: " + houseId);
    }

    public void viewTenantRentalHistory(String tenantId) {
        System.out.println("Viewing rental history for tenant: " + tenantId);
    }

    public void viewOwnerRentalHistory(String ownerId) {
        System.out.println("Viewing rental history for Owner: " + ownerId);
    }

    public void calculateTotalRent() {
        System.out.println("Total rent: " + rentAmount);
    }

    public void viewPendingRent() {
        if (!rentPaid) {
            System.out.println("Pending rent payment for Tenant: " + this.tenantId);
        } else {
            System.out.println("No pending rent for Tenant: " + this.tenantId);
        }
    }

    public void generateRentalInvoice() {
        System.out.println("Generating rental invoice for House: " + this.houseId);
    }

    public void exportRentalHistory() {
        System.out.println("Exporting rental history to file...");
    }

    public void verifyRentalPayment(Date startDate, Date endDate) {
        System.out.println("Verifying rental payment for period: " + startDate + " to " + endDate);
    }

    public void handleLateFees() {
        if (!rentPaid) {
            System.out.println("Applying late fees for overdue rent payment.");
        }
    }

    public void notifyTenantOnDueRent() {
        if (!rentPaid) {
            System.out.println("Notifying Tenant " + this.tenantId + " about due rent.");
        }
    }

    public static void main(String[] args) {
        RentalHistory rentalHistory = new RentalHistory("tenant123", "house456", 1200.0, new Date(), new Date());
        rentalHistory.addRentalRecord("house456", 1200.0, new Date(), new Date());
        rentalHistory.viewRentalHistory();
        rentalHistory.calculateTotalRent();
        rentalHistory.viewPendingRent();
        rentalHistory.generateRentalInvoice();
        rentalHistory.notifyTenantOnDueRent();
    }
}
