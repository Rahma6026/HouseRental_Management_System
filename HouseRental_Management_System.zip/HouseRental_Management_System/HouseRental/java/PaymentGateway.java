

import java.util.HashMap;
import java.util.Map;

class PaymentGateway {
    private Map<String, String> paymentTransactions;
    private Map<String, String> paymentMethods;

    public PaymentGateway() {
        paymentTransactions = new HashMap<>();
        paymentMethods = new HashMap<>();
    }

    // Process a payment transaction
    public void processPayment(String transactionId, double amount) {
        // Logic to process payment using an external payment provider
        paymentTransactions.put(transactionId, "Processed Payment of " + amount);
        System.out.println("Payment processed for Transaction ID: " + transactionId + " of amount " + amount);
    }

    // Refund a payment
    public void refundPayment(String transactionId) {
        // Logic to refund payment
        if (paymentTransactions.containsKey(transactionId)) {
            System.out.println("Refund initiated for Transaction ID: " + transactionId);
        } else {
            System.out.println("Transaction ID not found for refund.");
        }
    }

    // Verify a payment
    public void verifyPayment(String transactionId) {
        // Logic to verify payment
        if (paymentTransactions.containsKey(transactionId)) {
            System.out.println("Payment verified for Transaction ID: " + transactionId);
        } else {
            System.out.println("Transaction ID not found for verification.");
        }
    }

    // Initiate a refund
    public void initiateRefund(String transactionId) {
        // Logic to initiate a refund process
        if (paymentTransactions.containsKey(transactionId)) {
            System.out.println("Refund initiated for Transaction ID: " + transactionId);
        } else {
            System.out.println("Transaction ID not found to initiate refund.");
        }
    }

    // Cancel a transaction
    public void cancelTransaction(String transactionId) {
        // Logic to cancel the payment transaction
        if (paymentTransactions.containsKey(transactionId)) {
            paymentTransactions.remove(transactionId);
            System.out.println("Transaction ID " + transactionId + " has been cancelled.");
        } else {
            System.out.println("Transaction ID not found to cancel.");
        }
    }

    // Get details of a payment transaction
    public void getPaymentTransactionDetails(String transactionId) {
        // Retrieve details of the specified payment transaction
        if (paymentTransactions.containsKey(transactionId)) {
            System.out.println("Transaction Details for ID: " + transactionId + " - " + paymentTransactions.get(transactionId));
        } else {
            System.out.println("Transaction ID not found.");
        }
    }

    // Integrate with a payment provider
    public void integratePaymentProvider(String providerName) {
        // Integrate with external payment providers (PayPal, Stripe, etc.)
        System.out.println("Integrated with Payment Provider: " + providerName);
    }

    // Handle payment errors
    public void handlePaymentError(String errorCode, String errorMessage) {
        // Logic to handle payment errors
        System.out.println("Payment Error - Code: " + errorCode + ", Message: " + errorMessage);
    }

    // Generate a payment receipt
    public void generatePaymentReceipt(String transactionId) {
        // Logic to generate a receipt for the payment transaction
        if (paymentTransactions.containsKey(transactionId)) {
            System.out.println("Generated payment receipt for Transaction ID: " + transactionId);
        } else {
            System.out.println("Transaction ID not found for generating receipt.");
        }
    }

    // Send payment notification
    public void sendPaymentNotification(String userId, String notificationMessage) {
        // Logic to send payment notifications (Email, SMS, etc.)
        System.out.println("Sent payment notification to User ID: " + userId + " - " + notificationMessage);
    }

    // Track the status of a payment
    public void trackPaymentStatus(String transactionId) {
        // Logic to track the payment status (Pending, Completed, Failed)
        if (paymentTransactions.containsKey(transactionId)) {
            System.out.println("Tracking status for Transaction ID: " + transactionId);
        } else {
            System.out.println("Transaction ID not found for tracking.");
        }
    }

    // Manage payment methods (Add, Update, Remove)
    public void managePaymentMethods(String userId, String action, String method) {
        // Logic to manage payment methods (credit card, PayPal, etc.)
        switch (action.toLowerCase()) {
            case "add":
                paymentMethods.put(userId, method);
                System.out.println("Added payment method: " + method + " for User ID: " + userId);
                break;
            case "remove":
                paymentMethods.remove(userId);
                System.out.println("Removed payment method for User ID: " + userId);
                break;
            case "update":
                paymentMethods.put(userId, method);
                System.out.println("Updated payment method: " + method + " for User ID: " + userId);
                break;
            default:
                System.out.println("Invalid action for payment method management.");
        }
    }

    // Update payment settings (currency, taxes, etc.)
    public void updatePaymentSettings(String settingName, String settingValue) {
        // Logic to update payment settings
        System.out.println("Updated payment setting: " + settingName + " to " + settingValue);
    }

    // Initiate a payment dispute
    public void initiatePaymentDispute(String transactionId, String reason) {
       
        System.out.println("Payment dispute initiated for Transaction ID: " + transactionId + " due to: " + reason);
    }

    public static void main(String[] args) {
        
        PaymentGateway paymentGateway = new PaymentGateway();
        
        paymentGateway.processPayment("txn123", 200.0);
        paymentGateway.verifyPayment("txn123");
        paymentGateway.generatePaymentReceipt("txn123");
        paymentGateway.sendPaymentNotification("user789", "Your payment was successful!");
        paymentGateway.trackPaymentStatus("txn123");
    }
}
