

import java.util.HashMap;
import java.util.Map;

class MaintenanceRequest {
    private Map<String, String> maintenanceRequests;  // stores request ID and status
    private Map<String, String> techniciansAssigned;  // stores request ID and technician assigned
    private Map<String, String> maintenanceCosts;  // stores request ID and estimated cost

    public MaintenanceRequest() {
        maintenanceRequests = new HashMap<>();
        techniciansAssigned = new HashMap<>();
        maintenanceCosts = new HashMap<>();
    }

    // Create a new maintenance request
    public void createMaintenanceRequest(String requestId, String issueDescription) {
        maintenanceRequests.put(requestId, "Pending");
        System.out.println("Maintenance request created with ID: " + requestId + " - Issue: " + issueDescription);
    }

    // Assign a technician to the maintenance request
    public void assignTechnician(String requestId, String technicianName) {
        if (maintenanceRequests.containsKey(requestId)) {
            techniciansAssigned.put(requestId, technicianName);
            System.out.println("Technician " + technicianName + " assigned to request ID: " + requestId);
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // View the status of a maintenance request
    public void viewRequestStatus(String requestId) {
        String status = maintenanceRequests.getOrDefault(requestId, "Request not found.");
        System.out.println("Status of Maintenance Request ID " + requestId + ": " + status);
    }

    // Update the status of a maintenance request
    public void updateRequestStatus(String requestId, String status) {
        if (maintenanceRequests.containsKey(requestId)) {
            maintenanceRequests.put(requestId, status);
            System.out.println("Maintenance request ID " + requestId + " updated to status: " + status);
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Resolve the maintenance issue
    public void resolveMaintenanceIssue(String requestId) {
        if (maintenanceRequests.containsKey(requestId)) {
            maintenanceRequests.put(requestId, "Resolved");
            System.out.println("Maintenance request ID " + requestId + " has been resolved.");
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Track the maintenance request
    public void trackMaintenanceRequest(String requestId) {
        String status = maintenanceRequests.getOrDefault(requestId, "Request not found.");
        String technician = techniciansAssigned.getOrDefault(requestId, "No technician assigned.");
        System.out.println("Tracking Maintenance Request ID " + requestId + ": Status - " + status + ", Technician - " + technician);
    }

    // Schedule maintenance for a request
    public void scheduleMaintenance(String requestId, String date) {
        if (maintenanceRequests.containsKey(requestId)) {
            System.out.println("Maintenance scheduled for Request ID: " + requestId + " on " + date);
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Request approval for maintenance (from owner/admin)
    public void requestMaintenanceApproval(String requestId) {
        if (maintenanceRequests.containsKey(requestId)) {
            System.out.println("Approval requested for Maintenance Request ID: " + requestId);
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Notify the tenant about the maintenance request status
    public void notifyTenantOnMaintenanceStatus(String requestId) {
        String status = maintenanceRequests.getOrDefault(requestId, "Request not found.");
        System.out.println("Tenant notified about Maintenance Request ID " + requestId + " - Status: " + status);
    }

    // Estimate the cost of the maintenance request
    public void estimateMaintenanceCost(String requestId, double cost) {
        if (maintenanceRequests.containsKey(requestId)) {
            maintenanceCosts.put(requestId, String.valueOf(cost));
            System.out.println("Estimated maintenance cost for Request ID " + requestId + ": $" + cost);
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Cancel the maintenance request
    public void cancelMaintenanceRequest(String requestId) {
        if (maintenanceRequests.containsKey(requestId)) {
            maintenanceRequests.remove(requestId);
            techniciansAssigned.remove(requestId);
            maintenanceCosts.remove(requestId);
            System.out.println("Maintenance Request ID " + requestId + " has been canceled.");
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Log the details of the maintenance request
    public void logMaintenanceDetails(String requestId, String details) {
        if (maintenanceRequests.containsKey(requestId)) {
            System.out.println("Logging details for Maintenance Request ID " + requestId + ": " + details);
        } else {
            System.out.println("Maintenance request ID not found: " + requestId);
        }
    }

    // Archive completed maintenance requests
    public void archiveCompletedRequest(String requestId) {
        if (maintenanceRequests.containsKey(requestId) && maintenanceRequests.get(requestId).equals("Resolved")) {
            System.out.println("Archiving completed Maintenance Request ID: " + requestId);
        } else {
            System.out.println("Request is not resolved or ID not found: " + requestId);
        }
    }

    public static void main(String[] args) {
       
        MaintenanceRequest maintenanceRequest = new MaintenanceRequest();
        
        maintenanceRequest.createMaintenanceRequest("MR1001", "Leaking faucet in bathroom");
        maintenanceRequest.assignTechnician("MR1001", "Rahma Mahbub");
        maintenanceRequest.viewRequestStatus("MR1001");
        maintenanceRequest.updateRequestStatus("MR1001", "In Progress");
        maintenanceRequest.resolveMaintenanceIssue("MR1001");
        maintenanceRequest.trackMaintenanceRequest("MR1001");
        maintenanceRequest.scheduleMaintenance("MR1001", "2025-04-15");
        maintenanceRequest.requestMaintenanceApproval("MR1001");
        maintenanceRequest.notifyTenantOnMaintenanceStatus("MR1001");
        maintenanceRequest.estimateMaintenanceCost("MR1001", 150.00);
        maintenanceRequest.cancelMaintenanceRequest("MR1001");
        maintenanceRequest.logMaintenanceDetails("MR1001", "Technician completed the work successfully.");
        maintenanceRequest.archiveCompletedRequest("MR1001");
    }
}
