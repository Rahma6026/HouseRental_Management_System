

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.ArrayList;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class HouseTest {
    private House house;
    private List<House> houseList;
    private static final String ADDRESS = "123 Aftabnagar, Dhaka City";
    private static final double PRICE = 2500.00;
    private static final String OWNER = "Nisha";

    @Before
    public void setup() {
        house = new House(ADDRESS, PRICE, OWNER);
        houseList = new ArrayList<>();
        houseList.add(house);
    }

    @Test
    public void test01HouseCreation() {
        System.out.println("=== Test 1: House Creation ===");
        assertNotNull("House ID should not be null", house.getHouseId());
        assertTrue("House ID should start with 'H-'", house.getHouseId().startsWith("H-"));
        System.out.println("Created house with ID: " + house.getHouseId());
        System.out.println("Initial house details:");
        house.viewHouseDetails();
    }

    @Test
    public void test02UpdateHouseDetails() {
        System.out.println("\n=== Test 2: Update House Details ===");
        String newAddress = "456 Oak Ave, Town";
        double newPrice = 3000.00;
        
        System.out.println("Original details:");
        System.out.println("Address: " + house.getAddress());
        System.out.println("Price: $" + house.getPrice());
        
        house.updateHouseDetails(newAddress, newPrice);
        
        assertEquals("Address should be updated", newAddress, house.getAddress());
        assertEquals("Price should be updated", newPrice, house.getPrice(), 0.01);
        System.out.println("Updated details:");
        System.out.println("Address: " + house.getAddress());
        System.out.println("Price: $" + house.getPrice());
    }

    @Test
    public void test03AvailabilityManagement() {
        System.out.println("\n=== Test 3: Availability Management ===");
        System.out.println("Initial availability: " + house.isAvailable());
        
        house.markHouseAsRented();
        assertFalse("House should be marked as not available", house.isAvailable());
        
        house.markHouseAsAvailable();
        assertTrue("House should be marked as available", house.isAvailable());
    }

    @Test
    public void test04ImageUpload() {
        System.out.println("\n=== Test 4: Image Upload ===");
        String image1 = "front_view.jpg";
        String image2 = "interior.jpg";
        
        house.uploadHouseImages(image1);
        house.uploadHouseImages(image2);
        
        assertEquals("Should have 2 images", 2, house.getHouseImages().size());
        assertTrue("Should contain uploaded image", house.getHouseImages().contains(image1));
        System.out.println("Total images: " + house.getHouseImages().size());
    }

    @Test
    public void test05SearchByLocation() {
        System.out.println("\n=== Test 5: Search by Location ===");
        houseList.add(new House("789 Pine St, City", 2000.00, "Omi"));
        
        System.out.println("Searching for 'City':");
        House.searchHouseByLocation(houseList, "City");
        
        long cityCount = houseList.stream()
            .filter(h -> h.getAddress().toLowerCase().contains("city")).count();
        assertEquals("Should find 2 houses in City", 2, cityCount);
    }

    @Test
    public void test06SearchByPrice() {
        System.out.println("\n=== Test 6: Search by Price Range ===");
        houseList.add(new House("789 Pine St, City", 2000.00, "Omi"));
        houseList.add(new House("321 Elm St, Town", 3500.00, "Bob Wilson"));
        
        System.out.println("Searching for houses between $2000-$3000:");
        House.searchHouseByPrice(houseList, 2000.00, 3000.00);
    }

    @Test
    public void test07RentCalculation() {
        System.out.println("\n=== Test 7: Rent Calculation ===");
        int months = 6;
        double expectedTotal = PRICE * months;
        
        System.out.println("Calculating rent for " + months + " months");
        house.calculateRent(months);
        assertEquals("Total rent calculation", expectedTotal, PRICE * months, 0.01);
    }

    @Test
    public void test08OwnerAssignment() {
        System.out.println("\n=== Test 8: Owner Assignment ===");
        String newOwner = "Omi";
        
        System.out.println("Original owner: " + house.getOwnerName());
        house.assignOwner(newOwner);
        assertEquals("Owner should be updated", newOwner, house.getOwnerName());
        System.out.println("New owner: " + house.getOwnerName());
    }

    @Test
    public void test09HouseRemoval() {
        System.out.println("\n=== Test 9: House Removal ===");
        System.out.println("Initial house count: " + houseList.size());
        house.removeHouse();
        houseList.remove(house);
        assertEquals("House list should be empty", 0, houseList.size());
        System.out.println("Final house count: " + houseList.size());
    }

    @Test
    public void test10ListAllHouses() {
        System.out.println("\n=== Test 10: List All Houses ===");
        houseList.add(new House("789 Pine St, City", 2000.00, "Omi"));
        System.out.println("Listing all houses:");
        House.listHouses(houseList);
        assertEquals("Should have 2 houses listed", 2, houseList.size());
    }

    @Test
    public void test11HouseValidation() {
        System.out.println("\n=== Test 11: House Data Validation ===");
        house.validateHouseData();
        assertTrue("House data should be valid", 
            house.getAddress() != null && !house.getAddress().isEmpty() && house.getPrice() > 0);
    }

    @Test
    public void test12AvailabilityCheck() {
        System.out.println("\n=== Test 12: Availability Check ===");
        house.checkAvailability();
        assertTrue("New house should be available", house.isAvailable());
        
        house.markHouseAsRented();
        assertFalse("House should be unavailable after marking as rented", house.isAvailable());
        
        house.checkAvailability();
    }
}