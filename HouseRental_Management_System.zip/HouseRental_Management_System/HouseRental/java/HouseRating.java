

import java.util.HashMap;
import java.util.Map;

public class HouseRating {
    private final Map<String, Double> houseTotalRatings;
    private final Map<String, Integer> houseRatingCounts;
    
    public HouseRating() {
        houseTotalRatings = new HashMap<>();
        houseRatingCounts = new HashMap<>();
    }

   
    public boolean rateHouse(String houseId, int rating) {
        if (rating < 1 || rating > 5) {
            return false;
        }
        houseTotalRatings.put(houseId, 
            houseTotalRatings.getOrDefault(houseId, 0.0) + rating);
        houseRatingCounts.put(houseId, 
            houseRatingCounts.getOrDefault(houseId, 0) + 1);
        return true;
    }

   
    public Double getRating(String houseId) {
        return getAverageRating(houseId);
    }

  
    public int getRatingCount(String houseId) {
        return houseRatingCounts.getOrDefault(houseId, 0);
    }

   
    public Double getAverageRating(String houseId) {
        Double totalRating = houseTotalRatings.get(houseId);
        Integer count = houseRatingCounts.get(houseId);
        
        if (totalRating == null || count == null || count == 0) {
            return null;
        }
        return totalRating / count;
    }

 
    public Map<String, Double> getAllRatedHouses() {
        Map<String, Double> averages = new HashMap<>();
        for (String houseId : houseTotalRatings.keySet()) {
            averages.put(houseId, getAverageRating(houseId));
        }
        return averages;
    }

    
    public Map<String, Double> getHousesWithRating(int targetRating) {
        Map<String, Double> result = new HashMap<>();
        for (String houseId : houseTotalRatings.keySet()) {
            Double avgRating = getAverageRating(houseId);
            if (avgRating != null && Math.round(avgRating) == targetRating) {
                result.put(houseId, avgRating);
            }
        }
        return result;
    }


    public boolean removeRating(String houseId) {
        if (!houseTotalRatings.containsKey(houseId)) {
            return false;
        }
        houseTotalRatings.remove(houseId);
        houseRatingCounts.remove(houseId);
        return true;
    }

   
    public String getMostRatedHouse() {
        String mostRated = null;
        int maxRatings = 0;
        
        for (Map.Entry<String, Integer> entry : houseRatingCounts.entrySet()) {
            if (entry.getValue() > maxRatings) {
                maxRatings = entry.getValue();
                mostRated = entry.getKey();
            }
        }
        return mostRated;
    }
}